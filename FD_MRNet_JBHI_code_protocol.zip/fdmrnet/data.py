from __future__ import annotations

import csv
from pathlib import Path

import nibabel as nib
import numpy as np
import torch
from torch.utils.data import Dataset
import torch.nn.functional as F


def zscore_nonzero(x: np.ndarray) -> np.ndarray:
    mask = x != 0
    if not mask.any():
        return x.astype(np.float32)
    y = x.astype(np.float32, copy=True)
    mean, std = y[mask].mean(), y[mask].std()
    y[mask] = (y[mask] - mean) / max(float(std), 1e-6)
    return y


def make_lr(hr: torch.Tensor, scale: int, mode: str = "isotropic") -> torch.Tensor:
    if mode == "through_plane":
        size = (*hr.shape[-3:-1], max(1, hr.shape[-1] // scale))
    elif mode == "isotropic":
        size = tuple(max(1, n // scale) for n in hr.shape[-3:])
    else:
        raise ValueError(f"unsupported degradation mode: {mode}")
    lr_small = F.interpolate(hr[None], size=size, mode="trilinear", align_corners=False)[0]
    return lr_small


class NiftiSRDataset(Dataset):
    """Load a selected channel from 3D or 4D NIfTI manifest entries."""

    def __init__(self, root, manifest, patch_size, scale, training=False, modality_index=None,
                 degradation_mode="isotropic"):
        self.root = Path(root)
        self.patch_size = tuple(patch_size)
        self.scale = int(scale)
        self.training = training
        self.modality_index = modality_index
        self.degradation_mode = degradation_mode
        with open(manifest, newline="", encoding="utf-8") as f:
            self.rows = list(csv.DictReader(f))

    def __len__(self):
        return len(self.rows)

    def _crop(self, x: torch.Tensor) -> torch.Tensor:
        starts = []
        for n, p in zip(x.shape[-3:], self.patch_size):
            if n < p:
                raise ValueError(f"volume shape {tuple(x.shape)} is smaller than patch {self.patch_size}")
            starts.append(torch.randint(0, n - p + 1, ()).item() if self.training else (n - p) // 2)
        z, y, xx = starts
        pd, ph, pw = self.patch_size
        return x[:, z:z+pd, y:y+ph, xx:xx+pw]

    def __getitem__(self, index):
        row = self.rows[index]
        path = Path(row["hr_path"])
        if not path.is_absolute():
            path = self.root / path
        image = nib.load(str(path))
        dataobj = image.dataobj
        if len(image.shape) == 4:
            modality_index = self.modality_index
            if modality_index is None:
                modality_index = int(row.get("modality_index", 0))
            if not 0 <= modality_index < image.shape[3]:
                raise IndexError(f"modality_index {modality_index} outside image shape {image.shape}")
            array = np.asarray(dataobj[..., modality_index])
        elif len(image.shape) == 3:
            array = np.asarray(dataobj)
        else:
            raise ValueError(f"expected 3D or 4D NIfTI, got shape {image.shape}")
        array = zscore_nonzero(array)
        hr = torch.from_numpy(array).float().unsqueeze(0)
        hr = self._crop(hr)
        if self.training:
            for dim in (-1, -2, -3):
                if torch.rand(()) < 0.5:
                    hr = torch.flip(hr, (dim,))
        lr = make_lr(hr, self.scale, self.degradation_mode)
        return {"lr": lr, "hr": hr, "subject": row["subject"]}

