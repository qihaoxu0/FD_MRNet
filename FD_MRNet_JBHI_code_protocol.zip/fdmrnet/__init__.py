from .model import FDMRNet

__all__ = ["FDMRNet"]

