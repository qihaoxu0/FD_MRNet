from __future__ import annotations

import torch
from torch import Tensor
import torch.nn.functional as F

from .model import gaussian_blur3d, warp3d


def flow_smoothness(flow: Tensor) -> Tensor:
    dz = flow[:, :, 1:] - flow[:, :, :-1]
    dy = flow[:, :, :, 1:] - flow[:, :, :, :-1]
    dx = flow[:, :, :, :, 1:] - flow[:, :, :, :, :-1]
    return dz.square().mean() + dy.square().mean() + dx.square().mean()


def frequency_l1(pred: Tensor, target: Tensor) -> Tensor:
    pred_fft = torch.fft.rfftn(pred, dim=(-3, -2, -1), norm="ortho")
    target_fft = torch.fft.rfftn(target, dim=(-3, -2, -1), norm="ortho")
    return (torch.view_as_real(pred_fft) - torch.view_as_real(target_fft)).abs().mean()


def composite_loss(outputs, target: Tensor, weights):
    pred = outputs["sr"]
    pred_low, target_low = gaussian_blur3d(pred, 2.0), gaussian_blur3d(target, 2.0)
    pred_high, target_high = pred - pred_low, target - target_low
    reconstruction = F.l1_loss(pred_low, target_low) + F.l1_loss(pred_high, target_high)
    frequency = frequency_l1(pred, target)
    deformation = pred.new_zeros(())
    smoothness = pred.new_zeros(())
    for state in outputs["states"]:
        composite_flow = state["low_flow"] + state["high_flow"]
        deformation = deformation + F.l1_loss(warp3d(target, composite_flow), target)
        smoothness = smoothness + flow_smoothness(composite_flow)
    total = (
        weights["lambda_reconstruction"] * reconstruction
        + weights["lambda_frequency"] * frequency
        + weights["lambda_deformation"] * deformation
        + weights["lambda_smoothness"] * smoothness
    )
    return total, {
        "total": total.detach(), "reconstruction": reconstruction.detach(),
        "frequency": frequency.detach(), "deformation": deformation.detach(),
        "smoothness": smoothness.detach(),
    }

