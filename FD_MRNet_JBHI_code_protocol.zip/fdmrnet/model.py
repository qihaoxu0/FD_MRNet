"""Reference FD-MRNet implementation derived from the manuscript.

This is not official author code. Architectural assumptions are documented in
docs/REPRODUCTION_AUDIT.md.
"""

from __future__ import annotations

import math
from typing import Dict, Tuple

import torch
from torch import Tensor, nn
import torch.nn.functional as F


def _gaussian_kernel3d(sigma: float, device, dtype) -> Tensor:
    radius = max(1, int(math.ceil(3 * sigma)))
    x = torch.arange(-radius, radius + 1, device=device, dtype=dtype)
    g = torch.exp(-(x * x) / (2 * sigma * sigma))
    g = g / g.sum()
    kernel = g[:, None, None] * g[None, :, None] * g[None, None, :]
    return kernel[None, None]


def gaussian_blur3d(x: Tensor, sigma: float) -> Tensor:
    kernel = _gaussian_kernel3d(sigma, x.device, x.dtype)
    radius = kernel.shape[-1] // 2
    kernel = kernel.repeat(x.shape[1], 1, 1, 1, 1)
    padded = F.pad(x, (radius, radius, radius, radius, radius, radius), mode="replicate")
    return F.conv3d(padded, kernel, groups=x.shape[1])


class ConvAct(nn.Sequential):
    def __init__(self, cin: int, cout: int, kernel: int = 3):
        super().__init__(
            nn.Conv3d(cin, cout, kernel, padding=kernel // 2),
            nn.LeakyReLU(0.1, inplace=True),
        )


class FrequencyDisentanglement(nn.Module):
    def __init__(self, channels: int, sigma_low: float, sigma_high: float):
        super().__init__()
        self.sigma_low = sigma_low
        self.sigma_high = sigma_high
        self.low_refine = nn.Sequential(ConvAct(channels, channels, 5), ConvAct(channels, channels))
        self.high_refine = nn.Sequential(ConvAct(channels, channels), ConvAct(channels, channels))

    def forward(self, x: Tensor) -> Tuple[Tensor, Tensor]:
        smooth_1 = gaussian_blur3d(x, self.sigma_low)
        smooth_2 = gaussian_blur3d(x, self.sigma_high)
        low = self.low_refine(smooth_2)
        dog = smooth_1 - smooth_2
        high = self.high_refine((x - smooth_1) + dog)
        gate = torch.sigmoid(F.adaptive_avg_pool3d(low, 1))
        high = high * gate
        return low, high


class LocalAttention3D(nn.Module):
    """Memory-bounded attention over pooled 3D tokens."""

    def __init__(self, channels: int, heads: int):
        super().__init__()
        if channels % heads:
            raise ValueError("channels must be divisible by heads")
        self.attn = nn.MultiheadAttention(channels, heads, batch_first=True)
        self.proj = nn.Conv3d(channels, channels, 1)

    def forward(self, x: Tensor) -> Tensor:
        original_size = x.shape[-3:]
        pooled = F.adaptive_avg_pool3d(x, tuple(min(8, n) for n in original_size))
        tokens = pooled.flatten(2).transpose(1, 2)
        tokens, _ = self.attn(tokens, tokens, tokens, need_weights=False)
        y = tokens.transpose(1, 2).reshape_as(pooled)
        y = F.interpolate(y, size=original_size, mode="trilinear", align_corners=False)
        return x + self.proj(y)


def warp3d(x: Tensor, flow: Tensor) -> Tensor:
    """Warp x with voxel-unit flow ordered as (x, y, z)."""
    b, _, d, h, w = x.shape
    zz, yy, xx = torch.meshgrid(
        torch.linspace(-1, 1, d, device=x.device, dtype=x.dtype),
        torch.linspace(-1, 1, h, device=x.device, dtype=x.dtype),
        torch.linspace(-1, 1, w, device=x.device, dtype=x.dtype),
        indexing="ij",
    )
    base = torch.stack((xx, yy, zz), dim=-1)[None].expand(b, -1, -1, -1, -1)
    norm = flow.new_tensor([max(w - 1, 1) / 2, max(h - 1, 1) / 2, max(d - 1, 1) / 2])
    grid = base + flow.permute(0, 2, 3, 4, 1) / norm
    return F.grid_sample(x, grid, mode="bilinear", padding_mode="border", align_corners=True)


class FAFB(nn.Module):
    def __init__(self, channels: int, heads: int, sigma_low: float, sigma_high: float, max_disp: float):
        super().__init__()
        self.fd = FrequencyDisentanglement(channels, sigma_low, sigma_high)
        self.low_attn = LocalAttention3D(channels, heads)
        self.high_attn = LocalAttention3D(channels, heads)
        self.low_flow = nn.Conv3d(channels * 2, 3, 3, padding=1)
        self.high_flow = nn.Conv3d(channels * 2, 3, 3, padding=1)
        self.max_disp = max_disp
        self.se = nn.Sequential(
            nn.AdaptiveAvgPool3d(1), nn.Conv3d(channels * 2, channels // 4, 1),
            nn.LeakyReLU(0.1, inplace=True), nn.Conv3d(channels // 4, channels, 1), nn.Sigmoid()
        )
        self.gamma = nn.Parameter(torch.zeros(1, channels, 1, 1, 1))

    def forward(self, x: Tensor) -> Tuple[Tensor, Dict[str, Tensor]]:
        low, high = self.fd(x)
        low, high = self.low_attn(low), self.high_attn(high)
        low_flow = torch.tanh(self.low_flow(torch.cat((low, high), 1))) * self.max_disp
        low_warp = warp3d(low, low_flow)
        high_coarse = warp3d(high, low_flow)
        high_flow = torch.tanh(self.high_flow(torch.cat((low_warp, high_coarse), 1))) * self.max_disp
        high_warp = warp3d(high_coarse, high_flow)
        alpha = self.se(torch.cat((low_warp, high_warp), 1))
        fused = alpha * high_warp + (1 - alpha) * low_warp
        return x + self.gamma * fused, {"low": low, "high": high, "low_flow": low_flow, "high_flow": high_flow}


class FDMRNet(nn.Module):
    def __init__(self, in_channels=1, channels=48, blocks=6, attention_heads=4,
                 dog_sigma_low=1.0, dog_sigma_high=2.0, max_displacement=2.0):
        super().__init__()
        stem = [ConvAct(in_channels, channels)] + [ConvAct(channels, channels) for _ in range(3)]
        self.stem = nn.Sequential(*stem)
        self.blocks = nn.ModuleList([
            FAFB(channels, attention_heads, dog_sigma_low, dog_sigma_high, max_displacement)
            for _ in range(blocks)
        ])
        self.decoder = nn.Sequential(ConvAct(channels * 3, channels), ConvAct(channels, channels))
        self.reconstruct = nn.Conv3d(channels, in_channels, 3, padding=1)

    def forward(self, lr: Tensor, output_size=None):
        if output_size is None:
            output_size = lr.shape[-3:]
        base = F.interpolate(lr, size=output_size, mode="trilinear", align_corners=False)
        feat = self.stem(base)
        states = []
        for block in self.blocks:
            feat, state = block(feat)
            states.append(state)
        last = states[-1]
        decoded = self.decoder(torch.cat((feat, last["low"], last["high"]), 1))
        sr = base + self.reconstruct(decoded)
        return {"sr": sr, "states": states, "base": base}


if __name__ == "__main__":
    model = FDMRNet(channels=24, blocks=2)
    x = torch.randn(1, 1, 16, 32, 32)
    with torch.no_grad():
        out = model(x)
    print("input:", tuple(x.shape), "output:", tuple(out["sr"].shape))

