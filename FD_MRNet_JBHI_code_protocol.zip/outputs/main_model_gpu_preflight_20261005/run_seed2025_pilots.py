"""Durable, single-GPU queue: frozen seed-2025 training -> full validation -> review."""
import csv
import json
import os
import subprocess
import sys
import time
import traceback
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path('/mnt/e/Research/FD-MRNet-reproduction')
FROZEN = ROOT / 'outputs/main_model_validation_pilot_frozen_v1_20261005'
SOURCE = FROZEN / 'source'
OUT = ROOT / 'outputs/main_model_validation_pilot_v1_20261005'
sys.path.insert(0, str(SOURCE))
from fdmrnet.config import load_config, sha256_file
from fdmrnet.evaluation.evidence_protocol import build_file_inventory
from fdmrnet.utils.io import atomic_json_dump

def now():
    return datetime.now(timezone.utc).isoformat()

def verify():
    manifest = json.loads((FROZEN / 'ARTIFACT_MANIFEST.json').read_text())
    for rel, digest in manifest.items():
        if sha256_file(FROZEN / rel) != digest:
            raise RuntimeError(f'Frozen artifact hash mismatch: {rel}')
    protocol = json.loads((FROZEN / 'FROZEN_PROTOCOL.json').read_text())
    jobs = [j for j in protocol['jobs'] if j['seed'] == 2025]
    assert len(jobs) == 2 and all(j['stage'] == 'initial_validation_gate' for j in jobs)
    return protocol, jobs

def command(method, phase, args):
    verify()
    log = OUT / 'logs' / f'{method}_{phase}.log'
    with log.open('x') as stream:
        process = subprocess.Popen([sys.executable, *args], cwd=SOURCE, env={**os.environ, 'PYTHONPATH':str(SOURCE),
                                   'OMP_NUM_THREADS':'4','MKL_NUM_THREADS':'4'}, stdout=stream, stderr=subprocess.STDOUT)
        atomic_json_dump(dict(status='running', coordinator_pid=os.getpid(), child_pid=process.pid,
                             method=method, seed=2025, phase=phase, phase_started_at=now(),
                             log=str(log), command=[sys.executable,*args]), OUT / 'coordinator_status.json')
        code = process.wait()
    if code:
        raise RuntimeError(f'{method} {phase} exited {code}; preserved log: {log}')

def analysis(protocol, jobs):
    import numpy as np
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    sys.path.insert(0, str(SOURCE / 'scripts'))
    from collect_results import training_budget_policy
    summaries, frames = [], {}
    fig, axes = plt.subplots(1,2,figsize=(10,4))
    for job in jobs:
        method = job['method']
        cfg = load_config(FROZEN / job['config'])
        run = Path(cfg['experiment']['output_dir'])
        with (run / 'epoch_metrics.csv').open() as f:
            curve = list(csv.DictReader(f))
        assert len(curve) == 10 and [int(r['epoch']) for r in curve] == list(range(1,11))
        for row in curve:
            assert all(np.isfinite(float(v)) for v in row.values())
        axes[0].plot([int(r['epoch']) for r in curve],[float(r['train_total']) for r in curve],label=method)
        axes[1].plot([int(r['epoch']) for r in curve],[float(r['val_psnr']) for r in curve],label=method)
        evaluation = OUT / 'evaluation' / method
        with (evaluation / 'val125_subject_metrics.csv').open() as f:
            rows = list(csv.DictReader(f))
        assert len(rows) == 125 and len({r['subject'] for r in rows}) == 125
        frames[method] = {r['subject']: r for r in rows}
        audit = json.loads((evaluation / 'val125_audit.json').read_text())
        ck = run / 'epoch_010.pt'
        budget_path = ck.with_suffix('.budget.json')
        budget = json.loads(budget_path.read_text())
        budget_audit = dict(checkpoint_sha256=sha256_file(ck),training_budget_evidence_path=str(budget_path),
                            training_budget_evidence_sha256=sha256_file(budget_path))
        policy = training_budget_policy(cfg,budget_audit,False)
        assert budget['epochs_completed'] == 10 and budget['micro_batches'] == 6000
        metrics = {}
        for roi in ('brain','tumor'):
            for metric in ('psnr','ssim','nmse','hfen'):
                values = [float(r[f'sr_{roi}_{metric}']) for r in rows if not r[f'sr_{roi}_{metric}'].startswith('N/A')]
                assert values and np.isfinite(values).all()
                metrics[f'{roi}_{metric}'] = dict(mean=float(np.mean(values)),sd=float(np.std(values,ddof=1)),valid_n=len(values))
        summaries.append(dict(method=method,metrics=metrics,actual_budget=budget,training_budget_policy_sha256=policy,
                              total_epoch_seconds=sum(float(r['epoch_seconds']) for r in curve),
                              last_three_patch_psnr=[float(r['val_psnr']) for r in curve[-3:]],
                              full_volume_audit_sha256=sha256_file(evaluation / 'val125_audit.json')))
    assert frames['fdmrnet'].keys() == frames['matched_residual3d'].keys()
    differences = [float(frames['fdmrnet'][s]['sr_brain_psnr'])-float(frames['matched_residual3d'][s]['sr_brain_psnr']) for s in sorted(frames['fdmrnet'])]
    for ax,title,ylabel in zip(axes,('Training objectives (method-specific)','Fixed-patch validation monitor'),('Loss','Brain PSNR (dB)')):
        ax.set_title(title); ax.set_xlabel('Epoch'); ax.set_ylabel(ylabel); ax.legend(); ax.grid(alpha=.25)
    fig.tight_layout(); fig.savefig(OUT / 'validation_curves.png',dpi=180); fig.savefig(OUT / 'validation_curves.pdf'); plt.close(fig)
    report = dict(status='completed_pending_review',evidence_class='validation_pilot',seed=2025,summaries=summaries,
                  mean_paired_brain_psnr_difference=float(np.mean(differences)),
                  actual_budget_policies_equal=summaries[0]['training_budget_policy_sha256']==summaries[1]['training_budget_policy_sha256'],
                  full_final_budget_frozen=False,other_seeds_started=False,
                  next='Review full-volume outputs/geometry and validation convergence before independently freezing final training budget')
    atomic_json_dump(report,OUT / 'pilot_review.json')

def main():
    protocol,jobs = verify()
    OUT.mkdir(exist_ok=True)
    (OUT / 'logs').mkdir(exist_ok=True)
    (OUT / 'evaluation').mkdir(exist_ok=True)
    inventory = OUT / 'validation_inventory.json'
    mapping = OUT / 'path_map.json'
    atomic_json_dump({'mappings':[]},mapping)
    manifest = FROZEN / 'manifests/val.csv'
    with manifest.open() as f:
        subjects = [r['subject'] for r in csv.DictReader(f)]
    identities = build_file_inventory(manifest,mapping,'t1',subjects)
    frozen_inputs = json.loads((FROZEN / 'preflight_evidence/pilot_input_audit.json').read_text())
    expected = {item[role]['path']: item[role]['sha256'] for item in frozen_inputs['cases'] if item['split']=='val' for role in ('t1','seg')}
    assert all(expected[path] == identity['sha256'] for path,identity in identities['files'].items())
    atomic_json_dump(identities,inventory)
    for job in jobs:
        method = job['method']
        cfg_path = FROZEN / job['config']
        cfg = load_config(cfg_path)
        assert cfg['_config_sha256'] == job['config_sha256']
        command(method,'train',['scripts/train.py','--config',str(cfg_path)])
        ck = Path(cfg['experiment']['output_dir']) / 'epoch_010.pt'
        budget = ck.with_suffix('.budget.json')
        ep = dict(schema_version=1,protocol_id=f"{protocol['protocol_id']}_{method}_seed2025_val125",
                  fixture=False,evidence_class='diagnostic',dataset='BraTS2021',split='val',subject_ids=subjects,
                  checkpoint=dict(path=str(ck),sha256=sha256_file(ck)),
                  source_config=dict(path=str(cfg_path),sha256=cfg['_config_sha256']),
                  original_manifest=dict(path=str(manifest),sha256=sha256_file(manifest)),
                  path_map=dict(path=str(mapping),sha256=sha256_file(mapping)),
                  file_inventory=dict(path=str(inventory),sha256=sha256_file(inventory)),
                  training_budget_evidence=dict(path=str(budget),sha256=sha256_file(budget)),
                  freeze=dict(frozen_at=protocol['frozen_at'],checkpoint_selection_rule='final_epoch_10',
                              manifest_binding='bound_at_training',no_test_tuning=True),
                  notes=['Independent validation pilot only; no SOTA claim or test tuning; final budget not frozen.'])
        evaluation = OUT / 'evaluation' / method
        evaluation.mkdir()
        ep_path = evaluation / 'protocol.json'
        atomic_json_dump(ep,ep_path)
        command(method,'full_volume_val',['scripts/evaluate_evidence_protocol.py','evaluate',
                    '--protocol',str(ep_path),'--out-dir',str(evaluation),'--tag','val125','--device','cuda:0','--threads','4'])
    analysis(protocol,jobs)
    atomic_json_dump(dict(status='completed_pending_review',coordinator_pid=os.getpid(),completed_at=now(),
                         seeds_completed=[2025],full_final_budget_frozen=False,other_seeds_started=False),OUT / 'coordinator_status.json')

if __name__ == '__main__':
    try:
        main()
    except Exception as exc:
        OUT.mkdir(exist_ok=True)
        atomic_json_dump(dict(status='failed',coordinator_pid=os.getpid(),failed_at=now(),error=repr(exc),
                             traceback=traceback.format_exc(),other_seeds_started=False),OUT / 'coordinator_status.json')
        raise
