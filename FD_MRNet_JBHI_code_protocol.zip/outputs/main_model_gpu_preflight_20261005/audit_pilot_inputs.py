import csv
import json
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import nibabel as nib
import numpy as np
from fdmrnet.config import sha256_file

root = Path(__file__).resolve().parent
draft = root.parent / 'main_model_retrain_draft_20261005'
records = []
manifest_hashes = {}
rosters = {}
for split in ('train','val'):
    path = draft / f'draft_manifests/{split}.csv'
    manifest_hashes[split] = sha256_file(path)
    with path.open(newline='') as f:
        rows = list(csv.DictReader(f))
    rosters[split] = [r['subject'] for r in rows]
    assert len(rosters[split]) == len(set(rosters[split]))
    records.extend(dict(split=split, **r) for r in rows)
assert len(rosters['train']) == 1001 and len(rosters['val']) == 125
assert not set(rosters['train']) & set(rosters['val'])

def audit(row):
    result = dict(subject=row['subject'], split=row['split'])
    images = {}
    for role in ('t1','seg'):
        path = Path(row[role])
        assert path.is_file(), str(path)
        image = nib.load(path)
        assert tuple(image.shape) == (240,240,155), (row['subject'], image.shape)
        images[role] = image
        result[role] = dict(path=str(path), sha256=sha256_file(path), shape=list(image.shape),
                            affine=np.asarray(image.affine).tolist(), spacing=list(map(float,image.header.get_zooms()[:3])))
    assert np.allclose(images['t1'].affine, images['seg'].affine, atol=1e-4)
    return result

with ThreadPoolExecutor(max_workers=4) as pool:
    items = list(pool.map(audit, records))
owners = {}
for row in items:
    owners.setdefault(row['t1']['sha256'], []).append(dict(subject=row['subject'], split=row['split']))
duplicates = [v for v in owners.values() if len(v) > 1]
assert not duplicates, duplicates
report = dict(status='passed', scope='T1 and segmentation file hashes/header geometry; train and val only',
              train_subjects=1001, val_subjects=125, manifest_hashes=manifest_hashes,
              duplicate_compressed_T1_files=duplicates, cases=items, heldout_metrics_accessed=False,
              limitation='Header and file integrity audit; not a complete canonical-voxel equivalence audit or full-array finite scan')
(root / 'pilot_input_audit.json').write_text(json.dumps(report, indent=2))
print(json.dumps({k: report[k] for k in ('status','train_subjects','val_subjects','duplicate_compressed_T1_files')}))
