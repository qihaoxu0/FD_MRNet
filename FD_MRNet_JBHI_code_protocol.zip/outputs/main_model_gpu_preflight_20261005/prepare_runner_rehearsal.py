"""Generate real-data diagnostic configs separate from future validation pilots."""
import csv
import json
from pathlib import Path
import yaml
from fdmrnet.config import load_config, sha256_file

root = Path('/mnt/e/Research/FD-MRNet-reproduction')
out = root / 'outputs/main_model_gpu_preflight_20261005/runner_rehearsal_v2'
out.mkdir(parents=True, exist_ok=True)
draft = root / 'outputs/main_model_retrain_draft_20261005'
for split in ('train', 'val'):
    with (draft / f'draft_manifests/{split}.csv').open(newline='') as f:
        reader = csv.DictReader(f)
        row = next(reader)
        fields = reader.fieldnames
    with (out / f'{split}_one_case.csv').open('w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader(); writer.writerow(row)
jobs = []
for method in ('fdmrnet', 'matched_residual3d'):
    for mode in ('continuous', 'resume'):
        path = draft / f'configs/t1x4_shortbudget_{method}_seed2025.yaml'
        cfg = yaml.safe_load(path.read_text())
        cfg['experiment'].update(id=f'diagnostic_runner_{method}_{mode}', enabled=True,
                                 evidence_class='diagnostic', fixture=False,
                                 output_dir=str(out / f'{method}_{mode}'))
        cfg['experiment'].pop('exclusion_reason', None)
        cfg['data'].update(train_manifest=str(out / 'train_one_case.csv'),
                           val_manifest=str(out / 'val_one_case.csv'), train_samples_per_epoch=1,
                           val_samples_per_epoch=1, num_workers=0)
        cfg['training'].update(epochs=2, checkpoint_epochs=[1,2], record_actual_budget=True)
        config = out / f'{method}_{mode}.yaml'
        config.write_text(yaml.safe_dump(cfg, sort_keys=False), encoding='utf-8')
        jobs.append(dict(method=method, mode=mode, config=str(config),
                         config_sha256=load_config(config)['_config_sha256'], raw_config_sha256=sha256_file(config)))
(out / 'registry.json').write_text(json.dumps(dict(evidence_class='diagnostic', jobs=jobs), indent=2))
print(json.dumps({'rehearsal_configs': len(jobs), 'training_patch_dhw': [48,96,96]}))
