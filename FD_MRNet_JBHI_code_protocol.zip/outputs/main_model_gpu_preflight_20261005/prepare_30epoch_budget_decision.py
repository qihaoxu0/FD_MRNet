import csv
import json
from datetime import datetime, timezone
from pathlib import Path
import yaml
from fdmrnet.config import load_config, sha256_file

root=Path('/mnt/e/Research/FD-MRNet-reproduction')
out=root/'outputs/main_model_pilot_review_20261006'
frozen=root/'outputs/main_model_validation_pilot_frozen_v1_20261005'
review=json.loads((out/'review.json').read_text())
(out/'budget_configs').mkdir(exist_ok=False)
jobs=[]
for method in ('fdmrnet','matched_residual3d'):
    for seed in (2025,2026,2027):
        parent=frozen/f'configs/{method}_seed{seed}.yaml'
        cfg=yaml.safe_load(parent.read_text())
        cfg['experiment'].update(id=f'core_t1x4_30epoch_budget_v1_{method}_seed{seed}',enabled=False,
                                 evidence_class='independent_core_comparison',
                                 exclusion_reason='Budget decided; exact-attempt comparison policy, final held-out binding and target-runtime gate must be registered before training',
                                 output_dir=str(root/f'outputs/main_model_core30_v1_20261006/runs/{method}/seed{seed}'))
        cfg['training'].update(epochs=30,checkpoint_epochs=[1,5,10,20,30])
        path=out/f'budget_configs/{method}_seed{seed}.yaml'
        path.write_text(yaml.safe_dump(cfg,sort_keys=False),encoding='utf-8')
        resolved=load_config(path)
        assert cfg['model']==load_config(parent)['model'] and cfg['loss']==load_config(parent)['loss']
        jobs.append(dict(method=method,seed=seed,config=str(path),config_sha256=resolved['_config_sha256'],
                         raw_config_sha256=sha256_file(path),training_enabled=False))
decision=dict(protocol_id='main_model_t1x4_core30_budget_decision_20261006',
    decided_at=datetime.now(timezone.utc).isoformat(),status='budget_decided_not_execution_frozen',training_started=False,
    purpose='Independent core model/capacity-control comparison; not a complete published SOTA matrix',
    epochs=30,patches_per_epoch=600,planned_micro_batches_per_run=18000,
    planned_optimizer_attempts_per_run=18000,world_size_per_job=1,batch_size_per_gpu=1,
    gradient_accumulation=1,effective_global_batch_size=1,training_patch_dhw=[48,96,96],
    optimizer='AdamW',initial_learning_rate=5e-5,weight_decay=.001,
    scheduler=dict(name='CosineAnnealingLR',T_max=30,unit='epoch'),
    amp='FP16 with native GradScaler; skips are observed and disclosed, not relabeled as updates',
    methods=['fdmrnet','matched_residual3d'],seeds=[2025,2026,2027],total_runs=6,
    total_planned_micro_batches=108000,jobs=jobs,
    initialization='From scratch with registered seed; do not extend/resume the old T_max=10 checkpoint under changed config',
    checkpoint_rule='epoch_030.pt for the primary endpoint; no method-specific best-checkpoint selection',
    interim_monitoring_epochs=[10,20],interim_policy='Validation safety monitoring only; no retrospective method-specific budget changes or held-out tuning',
    convergence_rationale='Both fixed-patch monitors still improve near epoch10; the 10-epoch cosine schedule forces LR to zero. 30 epochs is a bounded longer-budget decision, not proof of convergence.',
    comparison_budget_definition='Equal declared patch/micro-batch/optimizer-attempt budget; successful updates may differ under native AMP and must be separately reported',
    no_compensating_hidden_steps=True,no_tolerance_relaxation=True,
    strict_successful_update_equivalence_claim_allowed=False,
    actual_budget_export_limitation='Current collector groups by verified actual counters. Do not bypass its unequal-budget rejection; any equal-attempt comparison grouping needs an explicit independently tested policy in a new source/protocol version.',
    primary_endpoint='Subject-level full-volume brain PSNR; tumor PSNR/SSIM/NMSE and normalized discrete Laplacian error must retain adverse outcomes',
    pilot_review_path=str(out/'review.json'),pilot_review_sha256=sha256_file(out/'review.json'),
    local_measured_extrapolation_hours=review['projected_local_30epoch_three_seed_core_hours'],
    compute_estimate_scope='RTX3060Ti, six sequential runs plus final validation inference, approximately 80 hours before setup/retries; not a dual-4090 quote',
    mandatory_before_start=['Register held-out manifest hashes before new training; no held-out performance inspection during design',
        'Implement/test explicit equal-attempt comparison grouping while retaining per-run actual evidence hashes',
        'Freeze executable source/config/output identity under a new protocol ID; these disabled files are planning artifacts',
        'Target-runtime forward/backward/AMP/resume precheck if changing environment or GPU',
        'Appropriate published strong comparator identity/protocol verification before expanding to a SOTA claim'],
    further_extension='If 30 epochs still show material validation improvement, register a separate common longer-budget experiment; never silently extend one model or select on test results')
(out/'BUDGET_DECISION.json').write_text(json.dumps(decision,indent=2),encoding='utf-8')
assert all(not load_config(j['config'])['experiment']['enabled'] for j in jobs)
verification=dict(status='verified',budget_configs=6,all_training_disabled=True,core_budget_epochs=30,
                  attempts_per_run=18000,total_attempts=108000,
                  budget_decision_sha256=sha256_file(out/'BUDGET_DECISION.json'),
                  prior_frozen_manifest_verified=all(sha256_file(frozen/rel)==digest for rel,digest in json.loads((frozen/'ARTIFACT_MANIFEST.json').read_text()).items()))
assert verification['prior_frozen_manifest_verified']
(out/'verification.json').write_text(json.dumps(verification,indent=2))
print(json.dumps(verification))
