import json
import os
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

root = Path('/mnt/e/Research/FD-MRNet-reproduction')
repo = root / 'jbhi_rr_source_v1/fdmrnet_rr'
out = root / 'outputs/main_model_gpu_preflight_20261005'
draft = root / 'outputs/main_model_retrain_draft_20261005'
os.environ['PYTHONPATH'] = str(repo)

def run(name, args):
    started = datetime.now(timezone.utc).isoformat()
    process = subprocess.run([sys.executable, *args], cwd=repo, text=True, capture_output=True)
    report = dict(name=name, started_at=started, completed_at=datetime.now(timezone.utc).isoformat(),
                  command=[sys.executable, *args], cwd=str(repo), exit_code=process.returncode,
                  stdout=process.stdout, stderr=process.stderr)
    (out / f'{name}.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
    print(json.dumps(dict(name=name, exit_code=process.returncode, stdout=process.stdout[-2500:], stderr=process.stderr[-1500:])), flush=True)
    if process.returncode:
        raise SystemExit(process.returncode)

run('full_pytest_cuda26', ['-c', 'import torch,pytest; torch.set_num_threads(4); raise SystemExit(pytest.main(["-q"]))'])
run('actual_patch_cuda_amp_resume', ['scripts/preflight_training_protocol.py',
    '--config', str(draft / 'configs/t1x4_shortbudget_fdmrnet_seed2025.yaml'),
    '--config', str(draft / 'configs/t1x4_shortbudget_matched_residual3d_seed2025.yaml'),
    '--out', str(out / 'actual_patch_attempt03')])
run('prepare_runner_rehearsal', [str(out / 'prepare_runner_rehearsal.py')])
rehearsal = out / 'runner_rehearsal_v2'
for method in ('fdmrnet', 'matched_residual3d'):
    run(f'{method}_continuous', ['scripts/train.py', '--config', str(rehearsal / f'{method}_continuous.yaml')])
    run(f'{method}_stop_epoch1', ['scripts/train.py', '--config', str(rehearsal / f'{method}_resume.yaml'), '--stop-after-epoch', '1'])
    run(f'{method}_resume_epoch2', ['scripts/train.py', '--config', str(rehearsal / f'{method}_resume.yaml'),
        '--resume', str(rehearsal / f'{method}_resume/epoch_001.pt')])
run('verify_runner_rehearsal', [str(out / 'verify_runner_rehearsal.py')])
