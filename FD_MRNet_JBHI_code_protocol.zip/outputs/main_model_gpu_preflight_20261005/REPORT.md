# 实际训练尺寸 GPU、AMP、resume 与预算预检

已完成两个核心模型的本地预检，并冻结独立的 **T1 ×4、10 epoch 验证阶段协议**。完整期刊比较的收敛预算尚未冻结。未启动该 10 epoch 验证阶段，未租用或连接服务器；原 PyTorch 2.1.2 CUDA 环境保留不变。

## 本次实际执行

使用独立 `/home/xqh/fdmrnet_preflight_20261005` 环境，PyTorch 2.6.0+cu124，RTX 3060 Ti 8 GB。安装方式参考 [PyTorch 官方历史版本说明](https://pytorch.org/get-started/previous-versions/)。依赖检查通过。所有命令、输出与退出码均保存为本目录 JSON。

| 检查 | FD-MRNet | 容量匹配 residual 对照 |
|---|---:|---:|
| 参数量 | 6,489,337 | 6,545,713 |
| HR patch / LR patch | 48×96×96 / 12×96×96 | 相同 |
| 完整尺寸峰值 allocated 显存 | 4705.60 MiB | 2371.34 MiB |
| 正常 AMP 有限值更新 | 通过 | 通过 |
| 人工注入 Inf 后跳过更新、降低 scale | 通过 | 通过 |
| 溢出时模型与 Adam 状态保持不变 | 通过 | 通过 |
| checkpoint 的模型、Adam、scheduler、scaler、CPU/CUDA RNG 精确恢复 | 通过 | 通过 |
| 恢复后继续成功更新 | 通过 | 通过 |
| 严格重复更新轨迹阈值 1×10⁻⁶ | **未通过** | 通过，差值 0 |

完整源码测试 **76 项通过，无 CUDA 测试跳过**，见 `full_pytest_cuda26.json`。实际训练入口也分别完成连续 2 个诊断 epoch，以及第 1 个 epoch 停止后恢复到第 2 个 epoch。每个分支均只使用一个训练病例、一个验证病例、每 epoch 一个实际训练 patch。它们不是正式性能实验。

实际入口两种分支均记录：2 micro-batches、2 次 optimizer 尝试、2 次真实更新、0 次 AMP 跳过、2 次 epoch scheduler 更新。独立 collector 核对账本成功，并按预期拒绝诊断预算的正式导出。详见 `runner_rehearsal_verification.json`。

## 保留的严格轨迹失败

首次完整尺寸预检因 FD 的最大参数差约 5.51×10⁻⁵ 而失败，保留 `attempt01_failed_command.json` 和 `actual_patch_attempt01/report.json`。后续检查把精确保存状态恢复与重复反向轨迹分别测量，**没有放宽 1×10⁻⁶ 阈值，也没有把该严格检查改记为通过**。

最终版本的完整尺寸重复更新最大参数差约 6.15×10⁻⁵；实际训练入口连续/恢复分支最终模型最大差约 1.19×10⁻⁵。模型、Adam、scheduler、scaler 的保存状态以及 RNG 恢复均精确一致。CUDA 报告 `grid_sampler_3d_backward_cuda` 和 `avg_pool3d_backward_cuda` 不支持确定性反向传播；这与观察到的更新差异一致，但本次未逐个算子隔离差异来源。

协议据实使用 **seeded / warn-only** 复现设置，不能写成逐 bit 确定性训练。若后续研究必须满足严格轨迹阈值，需要另行核查或更换确定性算子实现，按新协议重新预检；当前仅冻结带此限制的验证阶段。

## 预算记录的修复

新增 `fdmrnet/engine/budget.py` 并接入原 epoch 训练入口：

- 区分实际 micro-batch、采样 patch、optimizer 尝试、真实更新和 AMP 跳过，不用计划步数冒充执行次数。
- 每个 checkpoint 保存累计执行状态，并生成独立 checkpoint/config/train-manifest 绑定的 `*.budget.json` 与不可变事件日志副本。
- 保存训练源码快照、运行环境及包版本，resume 校验源码、运行环境、配置、清单、执行日志与计数后再写配置和状态。
- 新预算协议限制每模型单 GPU/进程、`num_workers=0` 和完整 accumulation 边界；双 GPU 可以跑两个独立模型，不改变每模型全局 batch。
- 修复无测试清单的验证草案被训练入口强制访问测试清单的问题；AMP 使用原生跳过语义，epoch scheduler 仍按 epoch 更新。
- collector 对启用新记录的预算重新读取日志计数，不能仅信任汇总 JSON。历史缺失的执行预算不会被这次修复补造。

实现说明在 `../../jbhi_rr_source_v1/fdmrnet_rr/TRAINING_BUDGET_PROTOCOL.md`。原训练文件副本保留于 `source_before/`。

## 数据与冻结产物

训练 1001 个、验证 125 个患者的清单无重复、无交叉；全部 T1 与分割文件存在，压缩文件哈希与头部形状、affine 核查通过，没有发现相同压缩 T1 文件。`pilot_input_audit.json` 明确限定检查范围：未完成逐体素等价性排查或全部数组的有限值扫描。没有读取 held-out 性能指标。

冻结目录：`../main_model_validation_pilot_frozen_v1_20261005/`。包含 6 份不可变配置、训练/验证清单、源码、锁定依赖、预检证据、`FROZEN_PROTOCOL.json`、文件哈希清单与验证记录。简化内部 SwinIR3D 完全排除于核心任务列表，尚不能宣称公开强基线比较或 SOTA。

冻结的预算为每模型 10 epoch ×600 sampled patches、每卡 batch 1、accumulation 1、单进程、AdamW 5×10⁻⁵、weight decay 0.001、按 epoch 的 cosine scheduler。6000 次尝试是计划值；真实更新以账本为准。主终点固定使用 `epoch_010.pt` 在全部 125 个验证患者上的全体积脑区 PSNR；`best.pt` 只保留作监控。

先执行两项 seed 2025 验证任务，再检查曲线、几何输出、实际预算与全体积验证覆盖。其余 seed 锁定等待验证阶段审查。完整收敛预算和经核验的公开强基线，需独立登记后才能用于完整期刊比较。服务器迁移需重新登记路径绑定并在目标 GPU 做预检，不能直接改路径却沿用旧配置哈希。
