import csv
import json
import os
import subprocess
import sys
import time
import traceback
from datetime import datetime,timezone
from pathlib import Path

ROOT=Path('/mnt/e/Research/FD-MRNet-reproduction')
FROZEN=ROOT/'outputs/main_model_core30_frozen_v1_20261006'
SOURCE=FROZEN/'source'
OUT=ROOT/'outputs/main_model_core30_v1_20261006'
sys.path.insert(0,str(SOURCE))
from fdmrnet.config import load_config,sha256_file
from fdmrnet.evaluation.evidence_protocol import build_file_inventory
from fdmrnet.utils.io import atomic_json_dump
sys.path.insert(0,str(SOURCE/'scripts'))
from collect_results import training_budget_policy,actual_training_budget_policy

def now():return datetime.now(timezone.utc).isoformat()
def verify():
    for rel,digest in json.loads((FROZEN/'ARTIFACT_MANIFEST.json').read_text()).items():
        if sha256_file(FROZEN/rel)!=digest:raise RuntimeError(f'Frozen file changed: {rel}')
    return json.loads((FROZEN/'FROZEN_PROTOCOL.json').read_text())

def command(job,phase,args):
    verify()
    label=f"{job['method']}_seed{job['seed']}"
    log=OUT/'logs'/f'{label}_{phase}.log'
    with log.open('x') as stream:
        p=subprocess.Popen([sys.executable,*args],cwd=SOURCE,
            env={**os.environ,'PYTHONPATH':str(SOURCE),'OMP_NUM_THREADS':'4','MKL_NUM_THREADS':'4'},
            stdout=stream,stderr=subprocess.STDOUT)
        atomic_json_dump(dict(status='running',method=job['method'],seed=job['seed'],phase=phase,
                             coordinator_pid=os.getpid(),child_pid=p.pid,phase_started_at=now(),
                             log=str(log),completed_jobs=completed),OUT/'coordinator_status.json')
        try:
            while p.poll() is None:
                if phase=='train':
                    cfg=load_config(FROZEN/job['config'])
                    events=Path(cfg['experiment']['output_dir'])/'training_execution.jsonl'
                    if events.exists():
                        lines=events.read_text().splitlines()
                        # Last line can be in flight; do not misclassify an incomplete write.
                        records=[]
                        for line in lines:
                            try:records.append(json.loads(line))
                            except json.JSONDecodeError:break
                        batches=[r for r in records if r['kind']=='micro_batch']
                        skips=sum(r['overflow'] for r in batches)
                        longest=run=0
                        for r in batches:
                            run=run+1 if r['overflow'] else 0;longest=max(longest,run)
                        if skips>18 or longest>3:
                            raise RuntimeError(f'Technical AMP stop: skips={skips}, consecutive={longest}; no hidden compensating steps')
                time.sleep(5)
            if p.returncode:raise RuntimeError(f'{label} {phase} exit={p.returncode}; log={log}')
        except BaseException:
            if p.poll() is None:
                p.terminate()
                try:p.wait(timeout=30)
                except subprocess.TimeoutExpired:p.kill();p.wait()
            raise

def main():
    protocol=verify()
    OUT.mkdir(exist_ok=True);(OUT/'logs').mkdir(exist_ok=True);(OUT/'evaluation').mkdir(exist_ok=True)
    mapping=OUT/'path_map.json';atomic_json_dump({'mappings':[]},mapping)
    manifest=FROZEN/'manifests/val.csv'
    with manifest.open() as f:subjects=[r['subject'] for r in csv.DictReader(f)]
    inventory=OUT/'validation_inventory.json'
    identities=build_file_inventory(manifest,mapping,'t1',subjects)
    old_inputs=json.loads((ROOT/'outputs/main_model_validation_pilot_frozen_v1_20261005/preflight_evidence/pilot_input_audit.json').read_text())
    expected={r[role]['path']:r[role]['sha256'] for r in old_inputs['cases'] if r['split']=='val' for role in ('t1','seg')}
    assert all(expected[path]==v['sha256'] for path,v in identities['files'].items())
    atomic_json_dump(identities,inventory)
    for job in protocol['jobs']:
        cfgpath=FROZEN/job['config'];cfg=load_config(cfgpath)
        assert cfg['_config_sha256']==job['config_sha256']
        command(job,'train',['scripts/train.py','--config',str(cfgpath)])
        ck=Path(cfg['experiment']['output_dir'])/'epoch_030.pt';bp=ck.with_suffix('.budget.json')
        budget=json.loads(bp.read_text())
        a=dict(checkpoint_sha256=sha256_file(ck),training_budget_evidence_path=str(bp),training_budget_evidence_sha256=sha256_file(bp))
        grouping=training_budget_policy(cfg,a,False)
        actual=actual_training_budget_policy(cfg,a,False)
        label=f"{job['method']}_seed{job['seed']}";evaluation=OUT/'evaluation'/label;evaluation.mkdir()
        ep=dict(schema_version=1,protocol_id=f"{protocol['protocol_id']}_{label}_val125",fixture=False,
            evidence_class='diagnostic',dataset='BraTS2021',split='val',subject_ids=subjects,
            checkpoint=dict(path=str(ck),sha256=sha256_file(ck)),source_config=dict(path=str(cfgpath),sha256=cfg['_config_sha256']),
            original_manifest=dict(path=str(manifest),sha256=sha256_file(manifest)),
            path_map=dict(path=str(mapping),sha256=sha256_file(mapping)),file_inventory=dict(path=str(inventory),sha256=sha256_file(inventory)),
            training_budget_evidence=dict(path=str(bp),sha256=sha256_file(bp)),
            freeze=dict(frozen_at=protocol['frozen_at'],checkpoint_selection_rule='final_epoch_30',manifest_binding='bound_at_training',no_test_tuning=True))
        epath=evaluation/'protocol.json';atomic_json_dump(ep,epath)
        command(job,'full_volume_val',['scripts/evaluate_evidence_protocol.py','evaluate','--protocol',str(epath),
                '--out-dir',str(evaluation),'--tag','val125','--device','cuda:0','--threads','4'])
        with (evaluation/'val125_subject_metrics.csv').open() as f:rows=list(csv.DictReader(f))
        assert len(rows)==125 and {r['subject'] for r in rows}==set(subjects)
        completed.append(dict(method=job['method'],seed=job['seed'],budget=budget,
                              actual_training_budget_sha256=actual,comparison_budget_sha256=grouping,
                              metrics=str(evaluation/'val125_subject_metrics.csv')))
        atomic_json_dump({'completed_jobs':completed,'heldout_metrics_accessed':False},OUT/'completed_runs.json')
    import numpy as np
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    fig,ax=plt.subplots(figsize=(8,5))
    summary=[]
    for job in protocol['jobs']:
        cfg=load_config(FROZEN/job['config'])
        with (Path(cfg['experiment']['output_dir'])/'epoch_metrics.csv').open() as f:curve=list(csv.DictReader(f))
        assert len(curve)==30
        ax.plot([int(r['epoch']) for r in curve],[float(r['val_psnr']) for r in curve],label=f"{job['method']} / {job['seed']}")
    for item in completed:
        with Path(item['metrics']).open() as f:rows=list(csv.DictReader(f))
        values={}
        for roi in ('brain','tumor'):
            for metric in ('psnr','ssim','nmse','hfen'):
                valid=[float(r[f'sr_{roi}_{metric}']) for r in rows if not r[f'sr_{roi}_{metric}'].startswith('N/A')]
                assert valid and np.isfinite(valid).all()
                values[f'{roi}_{metric}']=dict(mean=float(np.mean(valid)),sd=float(np.std(valid,ddof=1)),n=len(valid))
        summary.append(dict(method=item['method'],seed=item['seed'],metrics=values,optimizer_updates=item['budget']['optimizer_updates'],
                            optimizer_attempts=item['budget']['optimizer_attempts'],amp_skips=item['budget']['skipped_optimizer_updates']))
    assert len({r['comparison_budget_sha256'] for r in completed})==1
    ax.set(xlabel='Epoch',ylabel='Fixed-patch brain PSNR (dB)',title='Core30 validation monitor');ax.legend(fontsize=8);ax.grid(alpha=.25)
    fig.tight_layout();fig.savefig(OUT/'validation_curves.png',dpi=180);plt.close(fig)
    atomic_json_dump(dict(status='completed_pending_convergence_review',summaries=summary,
                         heldout_metrics_accessed=False,strict_successful_update_budget_equal=False,
                         budget_comparison='equal_attempts_v1',SOTA_claim_ready=False),OUT/'core30_review.json')
    atomic_json_dump(dict(status='completed_pending_review',completed_at=now(),completed_jobs=completed,
                         heldout_metrics_accessed=False),OUT/'coordinator_status.json')

completed=[]
if __name__=='__main__':
    try:main()
    except Exception as exc:
        OUT.mkdir(exist_ok=True)
        atomic_json_dump(dict(status='failed',error=repr(exc),traceback=traceback.format_exc(),failed_at=now(),
                             completed_jobs=completed),OUT/'coordinator_status.json');raise
