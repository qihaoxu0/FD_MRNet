import copy
import json
import shutil
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

import yaml
from fdmrnet.config import canonical_hash, load_config, sha256_file
from fdmrnet.engine.budget import source_identity

root = Path('/mnt/e/Research/FD-MRNet-reproduction')
checks = root / 'outputs/main_model_gpu_preflight_20261005'
draft = root / 'outputs/main_model_retrain_draft_20261005'
repo = root / 'jbhi_rr_source_v1/fdmrnet_rr'
out = root / 'outputs/main_model_validation_pilot_frozen_v1_20261005'
assert not out.exists(), 'Never overwrite a frozen protocol'
test = json.loads((checks / 'full_pytest_cuda26.json').read_text())
assert test['exit_code'] == 0 and '76 passed' in test['stdout'] and 'skipped' not in test['stdout']
patch = json.loads((checks / 'actual_patch_attempt03/report.json').read_text())
runner = json.loads((checks / 'runner_rehearsal_verification.json').read_text())
inputs = json.loads((checks / 'pilot_input_audit.json').read_text())
assert patch['status'] == runner['status'] == inputs['status'] == 'passed'
for report in patch['reports']:
    assert max(report['exact_checkpoint_state_restore_differences'].values()) == 0.
    assert report['rng_restored'] and report['forced_overflow_preserved_model_and_optimizer']
    assert report['executed_budget']['source_code_sha256'] == source_identity()['sha256']
    assert report['hr_shape'] == [1,1,48,96,96]
assert all(r['resumed_budget_matches_continuous'] and r['diagnostic_formal_export_rejected'] for r in runner['results'])
out.mkdir()
for folder in ('configs','manifests','source','preflight_evidence'):
    (out / folder).mkdir()
for split in ('train','val'):
    src = draft / f'draft_manifests/{split}.csv'
    assert sha256_file(src) == inputs['manifest_hashes'][split]
    shutil.copy2(src, out / f'manifests/{split}.csv')
jobs = []
for method in ('fdmrnet','matched_residual3d'):
    reference = next(r for r in patch['reports'] if r['method'] == method)
    for seed in (2025,2026,2027):
        source_config = draft / f'configs/t1x4_shortbudget_{method}_seed{seed}.yaml'
        cfg = yaml.safe_load(source_config.read_text())
        cfg['experiment'].update(id=f'pilot_v1_t1x4_{method}_seed{seed}', enabled=True,
                                 evidence_class='validation_pilot', fixture=False,
                                 output_dir=str(root / f'outputs/main_model_validation_pilot_v1_20261005/runs/{method}/seed{seed}'))
        cfg['experiment'].pop('exclusion_reason', None)
        cfg['training'].update(record_actual_budget=True, reproducibility_mode='seeded_warn_only')
        cfg['data']['train_manifest'] = str(out / 'manifests/train.csv')
        cfg['data']['val_manifest'] = str(out / 'manifests/val.csv')
        assert cfg['model'] == load_config(source_config)['model']
        assert cfg['loss'] == load_config(source_config)['loss']
        config = out / f'configs/{method}_seed{seed}.yaml'
        config.write_text(yaml.safe_dump(cfg, sort_keys=False), encoding='utf-8')
        resolved = load_config(config)
        jobs.append(dict(method=method, seed=seed, config=str(config.relative_to(out)),
                         config_sha256=resolved['_config_sha256'], raw_config_sha256=sha256_file(config),
                         parameters=reference['parameters'], parent_draft_config_sha256=load_config(source_config)['_config_sha256'],
                         stage='initial_validation_gate' if seed == 2025 else 'locked_pending_validation_review'))
files = []
for folder in ('fdmrnet','scripts','tests'):
    files += sorted((repo / folder).rglob('*.py'))
files += [repo / name for name in ('AGENTS.md','pyproject.toml','environment.yml','SERVER_RUNBOOK.md',
                                  'RESULTS_INTEGRITY_POLICY.md','MANUSCRIPT_REVISION_CHECKLIST.md',
                                  'EVALUATION_EVIDENCE_PROTOCOL.md','TRAINING_BUDGET_PROTOCOL.md')]
for src in files:
    dest = out / 'source' / src.relative_to(repo)
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dest)
for rel in ('full_pytest_cuda26.json','pilot_input_audit.json','runner_rehearsal_verification.json',
            'attempt01_failed_command.json','actual_patch_attempt03/report.json'):
    dest = out / 'preflight_evidence' / rel.replace('/', '_')
    shutil.copy2(checks / rel, dest)
for report in patch['reports']:
    src = checks / f"actual_patch_attempt03/{report['method']}/runtime.json"
    shutil.copy2(src, out / f"preflight_evidence/{report['method']}_runtime.json")
freeze = subprocess.run([sys.executable,'-m','pip','freeze'], check=True, text=True, capture_output=True).stdout
(out / 'requirements.lock.txt').write_text(freeze, encoding='utf-8')
prior_audit = json.loads((root / 'outputs/weight_recovery_followup_20261005/partial2253_validation/evaluation/partial2253_val00502_audit.json').read_text())
protocol = dict(schema_version=1, protocol_id='main_model_t1x4_validation_pilot_v1_20261005',
    status='frozen_validation_pilot_with_documented_nondeterminism', frozen_at=datetime.now(timezone.utc).isoformat(),
    scope='Independent 10-epoch validation pilot, not restoration of old tables and not a converged final SOTA experiment',
    MRI_pilot_training_started=False, complete_final_comparison_budget_frozen=False,
    jobs=jobs, methods=['fdmrnet','matched_residual3d'], seeds=[2025,2026,2027],
    excluded_main_baselines=['swinir3d'], baseline_limitation='Compact in-house SwinIR3D excluded; appropriate published strong comparator still needs identity/protocol verification',
    data=dict(dataset='BraTS2021', modality='t1', scale=4, train_subjects=1001, val_subjects=125,
              train_manifest_sha256=sha256_file(out / 'manifests/train.csv'), val_manifest_sha256=sha256_file(out / 'manifests/val.csv'),
              heldout_metrics_accessed=False, input_audit='preflight_evidence/pilot_input_audit.json',
              input_audit_scope=inputs['scope'], input_audit_limitations=inputs['limitation']),
    planned_budget=dict(epochs=10, sampled_patches_per_epoch=600, micro_batches=6000,
                       optimizer_attempts=6000, actual_optimizer_updates='Observed in event ledger; not equated with attempts',
                       world_size_per_job=1, batch_size_per_gpu=1, gradient_accumulation=1, effective_global_batch_size=1,
                       patch_size_dhw=[48,96,96], optimizer='AdamW', learning_rate=5e-5, weight_decay=.001,
                       scheduler=dict(name='CosineAnnealingLR', T_max=10, unit='completed_epoch'), num_workers=0, amp=True),
    checkpoint_selection_rule='epoch_010.pt only for primary pilot endpoint; best.pt is monitoring only',
    validation_monitor='Fixed central patch per validation subject; diagnostic curves only',
    primary_endpoint='Subject-level full-volume brain PSNR on all 125 validation subjects',
    evaluation_settings={key: prior_audit[key] for key in ('metric_protocol','normalization')},
    full_volume_inference=load_config(out / 'configs/fdmrnet_seed2025.yaml')['evaluation'],
    comparison_scope='End-to-end methods with disclosed method-specific losses; capacity control, not a single-module causal ablation or published SOTA comparison',
    reproducibility=dict(mode='seeded_warn_only', state_restore_requirement='Exact model/Adam/scheduler/scaler/CPU and CUDA RNG restoration',
                         strict_trajectory_threshold=1e-6, strict_trajectory_results={r['method']:r['strict_trajectory_passed'] for r in patch['reports']},
                         limitation='FD trajectory fails 1e-6 despite exact state restoration; CUDA grid-sample and pooling backward warn about unsupported determinism. No bitwise training-trajectory guarantee.',
                         tolerance_relaxed=False),
    execution_policy=dict(next_stage='Two seed-2025 validation pilots only', remaining_seeds='Locked pending validation gate review',
                          local_machine_prechecked='RTX 3060 Ti, torch 2.6.0+cu124', target_server_preflight_required=True,
                          test_external_evaluation_enabled=False, no_automatic_full_matrix=True),
    validation_gate=dict(requirements=['Complete 10 epochs for both seed-2025 methods with verified actual ledger',
        'All 125 full-volume validation subjects covered; finite primary metrics',
        'Inspect patch curves, full-volume outputs and geometry diagnostics for implementation anomalies',
        'Report unequal actual update counts or AMP skips; do not declare matched executed budgets when they differ',
        'Use validation convergence and measured runtime to register an independent final comparison budget before final training'],
        gate_already_completed=False))
(out / 'FROZEN_PROTOCOL.json').write_text(json.dumps(protocol,indent=2),encoding='utf-8')
(out / 'FROZEN_PROTOCOL.sha256').write_text(sha256_file(out / 'FROZEN_PROTOCOL.json')+'  FROZEN_PROTOCOL.json\n')
manifest = {str(p.relative_to(out)):sha256_file(p) for p in sorted(out.rglob('*')) if p.is_file()}
(out / 'ARTIFACT_MANIFEST.json').write_text(json.dumps(manifest,indent=2))
assert all(sha256_file(out / rel) == digest for rel,digest in manifest.items())
assert all(load_config(out / j['config'])['_config_sha256'] == j['config_sha256'] for j in jobs)
verification = dict(status='verified', files_verified=len(manifest), configs=6, protocol_sha256=sha256_file(out / 'FROZEN_PROTOCOL.json'),
                    artifact_manifest_sha256=sha256_file(out / 'ARTIFACT_MANIFEST.json'), MRI_pilot_training_started=False,
                    strict_FD_trajectory_passed=False, final_SOTA_protocol_ready=False)
(out / 'verification.json').write_text(json.dumps(verification,indent=2))
print(json.dumps(verification))
