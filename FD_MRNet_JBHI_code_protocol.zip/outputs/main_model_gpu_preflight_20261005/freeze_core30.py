import csv
import json
import shutil
import subprocess
import sys
from datetime import datetime,timezone
from pathlib import Path
import yaml
from fdmrnet.config import load_config,sha256_file

root=Path('/mnt/e/Research/FD-MRNet-reproduction')
out=root/'outputs/main_model_core30_frozen_v1_20261006'
old=root/'outputs/main_model_validation_pilot_frozen_v1_20261005'
decision=root/'outputs/main_model_pilot_review_20261006/BUDGET_DECISION.json'
assert not (out/'FROZEN_PROTOCOL.json').exists()
assert json.loads((out/'pytest_exit.json').read_text())['exit_code']==0
for folder in ('configs','manifests'):(out/folder).mkdir(exist_ok=True)
for split in ('train','val'):
    shutil.copy2(old/f'manifests/{split}.csv',out/f'manifests/{split}.csv')
test=root.parent.parent/'learn/manuscripts/第十篇FD-MRNet/JBHI/rej&resumbit/output/rr_validation_20260826_021819/manifests/brats2021_seed2025/test.csv'
# root is /mnt/e/Research/project; use the named original file, not image data.
test=Path('/mnt/e/learn/manuscripts/第十篇FD-MRNet/JBHI/rej&resumbit/output/rr_validation_20260826_021819/manifests/brats2021_seed2025/test.csv')
shutil.copy2(test,out/'manifests/test.csv')
rosters={}
for split in ('train','val','test'):
    with (out/f'manifests/{split}.csv').open() as f:rosters[split]=[r['subject'] for r in csv.DictReader(f)]
    assert len(rosters[split])==len(set(rosters[split]))
assert list(map(lambda s:len(rosters[s]),('train','val','test')))==[1001,125,125]
assert len(set(sum(rosters.values(),[])))==1251
jobs=[]
for seed in (2025,2026,2027):
    for method in ('fdmrnet','matched_residual3d'):
        src=root/f'outputs/main_model_pilot_review_20261006/budget_configs/{method}_seed{seed}.yaml'
        cfg=yaml.safe_load(src.read_text())
        cfg['experiment'].update(id=f'core30_v1_t1x4_{method}_seed{seed}',enabled=True,
                                 evidence_class='independent_core_comparison',
                                 output_dir=str(root/f'outputs/main_model_core30_v1_20261006/runs/{method}/seed{seed}'))
        cfg['experiment'].pop('exclusion_reason',None)
        cfg['training']['budget_comparison']='equal_attempts_v1'
        for split in rosters:cfg['data'][f'{split}_manifest']=str(out/f'manifests/{split}.csv')
        config=out/f'configs/{method}_seed{seed}.yaml'
        config.write_text(yaml.safe_dump(cfg,sort_keys=False))
        resolved=load_config(config)
        parent=load_config(old/f'configs/{method}_seed{seed}.yaml')
        assert cfg['model']==parent['model'] and cfg['loss']==parent['loss']
        jobs.append(dict(method=method,seed=seed,config=str(config.relative_to(out)),
                         config_sha256=resolved['_config_sha256'],raw_config_sha256=sha256_file(config)))
lock=subprocess.run([sys.executable,'-m','pip','freeze'],check=True,text=True,capture_output=True).stdout
previous=set((old/'requirements.lock.txt').read_text().splitlines())
current=set(lock.splitlines())
# The old pip-freeze cwd exposed the repository's egg-info. The project is
# imported from its frozen source, not installed in this virtual environment.
# Verify against the environment recorded by the completed pilot as well.
assert previous-current=={'fdmrnet-rr==0.1.0'} and not current-previous,'Installed dependency versions changed'
import importlib.metadata
from fdmrnet.engine.trainer import train_from_config  # match the actual runtime import context
import torch
_metadata_probe = torch.optim.AdamW(torch.nn.Linear(1,1).parameters())  # trigger optimizer's lazy imports, no training
packages={d.metadata['Name']:d.version for d in importlib.metadata.distributions() if d.metadata['Name']}
prior_runtime=json.loads((root/'outputs/main_model_validation_pilot_v1_20261005/runs/fdmrnet/seed2025/runtime.json').read_text())
assert packages==prior_runtime['packages'],'Actual completed-pilot runtime packages changed'
(out/'requirements.lock.txt').write_text(lock)
protocol=dict(protocol_id='main_model_t1x4_core30_v1_20261006',status='frozen_ready',
    frozen_at=datetime.now(timezone.utc).isoformat(),budget_decision_sha256=sha256_file(decision),jobs=jobs,
    stage='Independent core comparison on validation; not a complete SOTA matrix',
    epochs=30,patches_per_epoch=600,planned_micro_batches=18000,planned_optimizer_attempts=18000,
    optimizer='AdamW',learning_rate=5e-5,weight_decay=.001,scheduler={'name':'CosineAnnealingLR','T_max':30},
    world_size_per_job=1,batch_size_per_gpu=1,gradient_accumulation=1,
    initialization='From scratch; no resume/extension of T_max=10 checkpoints',
    primary_checkpoint='epoch_030.pt; best.pt monitoring only',budget_comparison='equal_attempts_v1',
    actual_update_equivalence_claim=False,amp_skip_acceptance_cap_fraction=.001,
    max_consecutive_amp_skips=3,skip_cap_meaning='Technical stop threshold, not proof that unequal updates have no effect',
    test_manifest_sha256=sha256_file(out/'manifests/test.csv'),test_roster_count=125,
    heldout_metrics_accessed=False,test_evaluation_enabled=False,
    completion_rule='Train six runs and full-volume val125; stop for convergence review before any held-out evaluation',
    published_strong_baseline_included=False,strict_FD_trajectory_passed=False,
    reused_full_shape_preflight=str(root/'outputs/main_model_gpu_preflight_20261005/actual_patch_attempt03/report.json'),
    reuse_reason='Same GPU/runtime/model/loss/trainer; only epoch budget, manifest binding and explicit grouping policy change. New grouping tests and full CUDA suite passed.')
protocol['runtime_lock_note']='Dependency versions match completed-pilot runtime exactly. Old lock additionally exposed workspace fdmrnet-rr egg-info; the project is bound by frozen source hashes, not a PyPI package.'
(out/'FROZEN_PROTOCOL.json').write_text(json.dumps(protocol,indent=2))
files={str(p.relative_to(out)):sha256_file(p) for p in sorted(out.rglob('*')) if p.is_file() and '__pycache__' not in p.parts}
(out/'ARTIFACT_MANIFEST.json').write_text(json.dumps(files,indent=2))
assert all(sha256_file(out/r)==s for r,s in files.items())
print(json.dumps({'protocol':protocol['protocol_id'],'configs':len(jobs),'test_subjects':125,'files_verified':len(files),'training_started':False}))
