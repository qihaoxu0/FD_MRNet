import csv
import json
from datetime import datetime, timezone
from pathlib import Path
import numpy as np

root = Path('/mnt/e/Research/FD-MRNet-reproduction')
pilot = root / 'outputs/main_model_validation_pilot_v1_20261005'
out = root / 'outputs/main_model_pilot_review_20261006'
out.mkdir(exist_ok=False)
def read(path):
    with path.open(newline='') as f:
        return list(csv.DictReader(f))
models = ('fdmrnet','matched_residual3d')
data = {m: read(pilot / f'evaluation/{m}/val125_subject_metrics.csv') for m in models}
subjects = [r['subject'] for r in data[models[0]]]
assert len(subjects) == len(set(subjects)) == 125
assert all([r['subject'] for r in data[m]] == subjects for m in models)
stats, paired = [], []
rng = np.random.default_rng(20261006)
indices = rng.integers(0,125,size=(20000,125))
for roi in ('brain','tumor'):
    for metric in ('psnr','ssim','nmse','hfen'):
        key = f'sr_{roi}_{metric}'
        a = np.array([float(r[key]) for r in data[models[0]]])
        b = np.array([float(r[key]) for r in data[models[1]]])
        assert np.isfinite(a).all() and np.isfinite(b).all()
        baseline = f'baseline_{roi}_{metric}'
        assert np.allclose([float(r[baseline]) for r in data[models[0]]],
                           [float(r[baseline]) for r in data[models[1]]],rtol=0,atol=1e-8)
        d = a-b
        ci = np.quantile(d[indices].mean(axis=1),[.025,.975])
        positive_better = metric in ('psnr','ssim')
        wins = int(np.sum(d>0 if positive_better else d<0))
        stats.append(dict(roi=roi,metric=metric,n=125,fd_mean=float(a.mean()),control_mean=float(b.mean()),
                          fd_minus_control_mean=float(d.mean()),median_difference=float(np.median(d)),
                          subject_bootstrap_95ci=ci.tolist(),fd_better_cases=wins,
                          ci_scope='Conditional on this single trained seed pair; not uncertainty across training seeds'))
        paired.extend(dict(subject=s,roi=roi,metric=metric,fd=float(x),control=float(y),difference=float(z)) for s,x,y,z in zip(subjects,a,b,d))
curves,overflows,times = {},{},{}
for m in models:
    rows = read(pilot / f'runs/{m}/seed2025/epoch_metrics.csv')
    psnr = np.array([float(r['val_psnr']) for r in rows])
    curves[m] = dict(epoch8_to10_patch_psnr_gain=float(psnr[-1]-psnr[-3]),
                     epoch7_to10_patch_psnr_gain=float(psnr[-1]-psnr[-4]),
                     last3_patch_psnr_slope_db_per_epoch=float(np.polyfit([8,9,10],psnr[-3:],1)[0]),
                     late_rec_losses=[float(r['train_rec']) for r in rows[-3:]],
                     final_recorded_learning_rate=float(rows[-1]['learning_rate']),
                     nonfinite_epoch_values=any(not np.isfinite(float(v)) for r in rows for v in r.values()))
    events=[json.loads(line) for line in (pilot / f'runs/{m}/seed2025/training_execution.jsonl').read_text().splitlines()]
    overflows[m] = [r for r in events if r.get('overflow')]
    assert len([r for r in events if r['kind']=='micro_batch']) == 6000
    budget=json.loads((pilot / f'runs/{m}/seed2025/epoch_010.budget.json').read_text())
    assert budget['skipped_optimizer_updates']==len(overflows[m])
    evaluation_seconds=sum(float(r['seconds']) for r in data[m])
    times[m]=dict(epoch_seconds=[float(r['epoch_seconds']) for r in rows],
                  training_and_patch_validation_hours=sum(float(r['epoch_seconds']) for r in rows)/3600,
                  final_full_volume_inference_hours=evaluation_seconds/3600)
projected_hours=sum(3*3*t['training_and_patch_validation_hours']+3*t['final_full_volume_inference_hours'] for t in times.values())
report=dict(created_at=datetime.now(timezone.utc).isoformat(),stats=stats,curves=curves,overflow_events=overflows,
            timing_measurements=times,projected_local_30epoch_three_seed_core_hours=projected_hours,
            projection_limitations='Linear extrapolation on RTX3060Ti; includes patch monitoring and final inference, excludes setup/retries; not a server quote',
            primary_endpoint='brain PSNR; other metrics exploratory',heldout_metrics_accessed=False,
            strict_equal_successful_update_budget=False,final_training_started=False)
(out/'review.json').write_text(json.dumps(report,indent=2))
with (out/'paired_differences.csv').open('w',newline='') as f:
    writer=csv.DictWriter(f,fieldnames=paired[0].keys());writer.writeheader();writer.writerows(paired)
print(json.dumps(report,indent=2))
