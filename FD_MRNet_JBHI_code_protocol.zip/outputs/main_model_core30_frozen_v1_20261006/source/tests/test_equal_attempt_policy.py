import copy
import json
import sys
from pathlib import Path
import pytest
from fdmrnet.config import sha256_file
from fdmrnet.engine.budget import TrainingBudgetLedger
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
from collect_results import training_budget_policy, actual_training_budget_policy

def fixture(root, skips=0, batches=2000):
    root.mkdir()
    train=root.parent/'train.csv'
    train.write_text('subject\nfixture_case\n')
    cfg={'_config_sha256':'c'*64,'experiment':{'fixture':True},
         'data':{'train_manifest':str(train),'train_samples_per_epoch':1000,'patch_size_dhw':[8,16,16]},
         'training':dict(epochs=2,batch_size_per_gpu=1,gradient_accumulation=1,target_global_batch_size=1,
                         learning_rate=.001,weight_decay=.001,record_actual_budget=True,budget_comparison='equal_attempts_v1')}
    ledger=TrainingBudgetLedger(root,cfg,{'train':sha256_file(train)})
    for i in range(batches):
        skipped=i<skips
        ledger.micro_batch(i//1000+1,i%1000+1,1,.5,dict(optimizer_updated=not skipped,overflow=skipped,new_scale=64.))
        if i in (999,1999): ledger.epoch_completed(i//1000+1)
    ck=root/'epoch_002.pt';ck.write_bytes(b'synthetic technical fixture only')
    ledger.bind_checkpoint(ck)
    audit=dict(checkpoint_sha256=sha256_file(ck),training_budget_evidence_path=str(ck.with_suffix('.budget.json')),
               training_budget_evidence_sha256=sha256_file(ck.with_suffix('.budget.json')))
    return cfg,audit

def test_explicit_equal_attempt_group_preserves_unequal_actual_digests(tmp_path):
    a,aa=fixture(tmp_path/'a',0);b,bb=fixture(tmp_path/'b',1)
    assert training_budget_policy(a,aa)==training_budget_policy(b,bb)
    assert actual_training_budget_policy(a,aa)!=actual_training_budget_policy(b,bb)
    a['training'].pop('budget_comparison');b['training'].pop('budget_comparison')
    assert training_budget_policy(a,aa)!=training_budget_policy(b,bb)

def test_unequal_attempts_and_excess_skips_rejected(tmp_path):
    a,aa=fixture(tmp_path/'a',0,1999)
    # The old verifier already rejects incomplete scheduler/epoch evidence.
    with pytest.raises(RuntimeError):training_budget_policy(a,aa)
    b,bb=fixture(tmp_path/'b',3)
    with pytest.raises(RuntimeError,match='0.1%'):training_budget_policy(b,bb)
