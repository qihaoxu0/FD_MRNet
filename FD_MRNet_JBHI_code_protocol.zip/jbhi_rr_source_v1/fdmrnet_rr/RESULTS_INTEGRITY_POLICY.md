# Results integrity policy

- `placeholders/` contains layout aids only. Every file is marked simulated and is
  rejected by submission-mode scripts.
- Legacy manuscript numbers are never optimization targets and are never copied into
  revised tables.
- Hyperparameters are selected on validation subjects only. The test split is evaluated
  once after the method/config/checkpoint rule is frozen.
- A main condition is complete only after three seeds and full-volume evaluation.
- Checkpoints, resolved configs, split manifests, and result CSVs are SHA256 recorded.
- A missing, NaN, or empty tumor ROI remains missing and is accompanied by valid n; it
  is never replaced with zero or silently dropped from the denominator.
- Patch metrics are diagnostics. Only subject-level full-volume metrics support paper
  claims.
- No synthetic or projected number may appear in a submission manuscript or rebuttal.
