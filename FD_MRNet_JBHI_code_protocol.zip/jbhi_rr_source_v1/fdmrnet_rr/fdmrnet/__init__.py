"""FD-MRNet reject-and-resubmit implementation."""

__version__ = "0.1.0"

