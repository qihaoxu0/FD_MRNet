# Server runbook

Run all commands from the repository root.

## 1. Install and verify

```bash
conda env create -f environment.yml
conda activate fdmrnet-rr
pip install -e .
pytest -q
python scripts/preflight.py --config configs/main/brats2021_t1_x2.yaml
```

Do not begin the formal matrix unless every test passes and preflight reports finite
forward/backward values.

Verify the declared capacity control on the target PyTorch build and, if the reported
best candidate differs, update the `matched_residual3d` registry entry before freezing
configs:

```bash
python scripts/match_capacity.py --target-config configs/main/brats2021_t1_x4.yaml \
  --with-flops --out outputs/audits/capacity_match.json
```

## 2. Audit and split datasets

```bash
python scripts/audit_dataset.py --root /data/BraTS2021 --corrections-root /data/BraTS2021_Corrections \
  --out manifests/brats2021_dataset_audit.json
python scripts/generate_splits.py --root /data/BraTS2021 \
  --corrections-root /data/BraTS2021_Corrections --out-dir manifests/brats2021 \
  --seed 2025 --train 1001 --val 125 --test 125

python scripts/audit_dataset.py --root /data/BraTS2023_GLI_Validation \
  --external-eval-without-seg --out manifests/brats2023_validation_dataset_audit.json

python scripts/audit_cross_dataset.py \
  --dataset-a manifests/brats2021/all.csv --dataset-b manifests/brats2023_validation/all.csv \
  --full-voxel-hash --out manifests/brats2021_vs_2023_overlap.json
```

Inspect every audit. If the local BraTS2021 count is not exactly 1251, do not force the
1001/125/125 command; explain the provenance difference and regenerate counts.

BraTS2023 GLI Training must remain `excluded_duplicate_of_brats2021`. GLI Validation
must contain exactly 219 paired T1n/T2w cases and have zero canonical-voxel overlap with
BraTS2021 before it may be labeled a non-overlapping external evaluation set. It has no
segmentation, so tumor metrics must be written as `N/A: segmentation unavailable`.

## 3. Stage the experiments

First materialize one-seed proposed-model pilots:

```bash
python scripts/materialize_experiments.py --groups main --seeds 2025 --out-dir generated_pilot
```

For each pilot config, train to epoch 10, inspect validation/geometry/qualitative output,
then resume. Do not inspect the test set during model design.

```bash
torchrun --standalone --nproc_per_node=4 scripts/train.py \
  --config generated_pilot/main/brats2021_t1_x2_fdmrnet_seed2025.yaml --stop-after-epoch 10

torchrun --standalone --nproc_per_node=4 scripts/train.py \
  --config generated_pilot/main/brats2021_t1_x2_fdmrnet_seed2025.yaml \
  --resume outputs/formal/brats2021_t1_x2/fdmrnet/seed2025/epoch_010.pt
```

After the protocol is frozen, create the complete matrix:

```bash
python scripts/materialize_experiments.py --out-dir generated_configs
N=$(wc -l < generated_configs/all_configs.txt)
sbatch --array=0-$((N-1))%4 slurm/train_generated_array.sbatch generated_configs/all_configs.txt
```

The full default matrix is intentionally large: 24 proposed runs, 120 shared-protocol
baseline runs, and 42 ablation/sensitivity runs. If compute is limited, finish all proposed runs,
then one seed of every baseline as a screening stage; however, final statistical claims
require the declared three seeds.

## 4. Evaluate without test-set tuning

```bash
N=$(wc -l < generated_configs/all_configs.txt)
sbatch --array=0-$((N-1))%4 slurm/evaluate_generated_array.sbatch generated_configs/all_configs.txt
```

Save qualitative volumes for subject IDs fixed before looking at model errors:

```bash
python scripts/evaluate_full_volume.py --config CONFIG.yaml --checkpoint CHECKPOINT.pt \
  --split test --tag final_test --save-subject SUBJECT_A --save-subject SUBJECT_B
```

## 5. Geometry and efficiency

```bash
python scripts/evaluate_geometry.py --config CONFIG.yaml --checkpoint CHECKPOINT.pt \
  --cases 50 --out outputs/audits/geometry.csv
python scripts/plot_geometry.py --input outputs/audits/geometry_examples/case_000.npz \
  --out outputs/figures/geometry_case_000.png

python scripts/evaluate_efficiency.py --config CONFIG.yaml --checkpoint CHECKPOINT.pt \
  --warmup 10 --repeats 5 --submission-mode --out outputs/audits/efficiency.json
```

Run efficiency serially on the same idle GPU for every method.

## 6. Collect immutable results and build paper artifacts

```bash
python scripts/collect_results.py --run-manifest generated_configs/run_manifest.csv \
  --out COMPLETED_RESULTS.yaml
python scripts/build_tables.py --registry COMPLETED_RESULTS.yaml --out outputs/paper_tables \
  --submission-mode --expected-seeds 3
python scripts/run_statistics.py \
  --metrics-long outputs/paper_tables/subject_seed_metrics_long.csv \
  --registry COMPLETED_RESULTS.yaml --submission-mode \
  --out outputs/statistics
python scripts/build_figures.py --summary outputs/paper_tables/main_results_long.csv \
  --run-manifest generated_configs/run_manifest.csv --out outputs/paper_figures
python scripts/verify_artifacts.py outputs/paper_tables outputs/paper_figures outputs/statistics
```

Only after the final verification passes should the real values replace manuscript
placeholders.

Formal statistics revalidate the registry and require the supplied long CSV to match
the registry-derived observations. Comparisons remain separate by split and named
training regime, with exact subject and seed pairing. The prespecified one-sided
`greater` hypothesis is recorded in the output; it is never reversed after seeing
the results. With fewer than two patients, means remain descriptive and CI/p-values
are `N/A`.

For a technical diagnostic rehearsal, omit `--submission-mode` and use a separate
output directory. Such outputs carry `NOT_FOR_SUBMISSION` and cannot replace formal
paper evidence. Do not combine different training regimes into a claim of matched
training budgets.
