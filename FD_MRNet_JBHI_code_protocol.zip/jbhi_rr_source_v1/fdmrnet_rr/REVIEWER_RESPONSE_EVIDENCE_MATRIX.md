# Reviewer-response evidence matrix

This is a drafting map, not the final rebuttal. Page/line references must be added only
after the revised manuscript is typeset.

| Concern | Required manuscript action | Code/evidence |
|---|---|---|
| R1/R3 task ambiguity | One single-input, same-contrast through-plane definition; T1/T2 independent | main YAMLs; task equation in revision checklist |
| R1/R3 scales/degradation | Keep ×2/×4; define blur→center decimation on depth | `fdmrnet/degradation/`; `test_degradation.py` |
| R1/R3 split/leakage | Report subject counts, manifest hashes, zero within-dataset overlap | `generate_splits.py`, `audit_dataset.py` |
| R1/R3 cross-dataset overlap | Audit IDs and canonical voxel hashes before calling BraTS2023 independent | `audit_cross_dataset.py` |
| R1/R3 Table I/II conflict | Delete both legacy tables; regenerate one table per dataset | `build_tables.py` submission mode |
| R1/R3 ablation arithmetic | Generate text/tables from logs; no hand-entered deltas | `main_results_long.csv`, statistics JSON |
| R1/R3 incomplete ablation | Isolate LF/HF, fields, gate, attention, fusion, block/global residuals, every loss, blur | `configs/ablations/` |
| R1/R3 capacity explanation | Add matched residual control and exact parameter counts | `match_capacity.py`, `preflight.py` |
| R1/R3 duplicated Table III rows | Every method/contrast has separate immutable CSV/hash | `collect_results.py`, result registry |
| R1/R3 metric ambiguity | Full-volume 3D metrics, data range/mask/window/valid n declared | `evaluation/full_volume.py`, `metrics/` |
| R1/R3 figure mismatch | Rebuild figures from named real inputs; re-audit cross-references | `build_figures.py`, `plot_qualitative.py`, `plot_geometry.py` |
| R1/R3 trivial deformation loss | Remove identity warp; supervise known synthetic fields and reconstruction alignment | `losses/composite.py`, geometry augmentation |
| R1/R3 reproducibility details | Publish dimensions, channels, blocks, windows, sigmas, weights, bounds | base YAML; architecture checklist |
| R1/R3 field validity | EPE, displacement magnitude, Jacobian and folding; examples | `evaluate_geometry.py`, `plot_geometry.py` |
| R1/R2/R3 old baselines | Common-protocol CNN, transformer, spectral and capacity controls | `models/baselines.py`, generated matrix |
| R3 DDLSR | Cite/discuss; quantify only with compatible official/author implementation | `EXTERNAL_BASELINES.md` |
| R3 unsupported transformer efficiency | Quantify accuracy/params/FLOPs/memory/latency on one protocol | `evaluate_efficiency.py` |
| R1/R3 no statistics | 3 seeds; subject-paired bootstrap CI/Wilcoxon/Holm | `run_statistics.py` |
| R1/R3 Set7 | Delete dataset, results, figures, claims, and incorrect citation | registry exclusion; no Set7 loader/config |
| R2 duplicated equations | Collapse old (1)/(11), (2)/(12); define branch warps separately | replacement equation list |
| R2 unclear ψFD/Eqs. 13–14 | Define split, branch refinement, gate, then fusion in order | architecture checklist; `blocks.py` |
| R2 inconsistent Eqs. 7–8 | Introduce named low/high warped features | replacement Eq. 6 |
| R2 undefined F(K) | Replace with explicit final block feature and decoder | replacement Eqs. 8–9 |
| R2 unclear loss variables | Define prediction/target/LP/HP/field sources | replacement loss block |
| R2 “fully convolutional” | Replace with “fully volumetric ... with local self-attention” | terminology checklist |
| R2 unsupported Dice | Remove claim unless a real segmentation protocol is run | manuscript checklist |
| R3 runtime mismatch | Same device/input/precision/preprocessing/warm-up/repeats | efficiency JSON protocol |
| R3 citation errors | Manually verify every bibliography item | mandatory reference audit |

## Final response-writing rule

For every response paragraph, cite: (1) revised page/line range, (2) exact code/config,
(3) result filename and SHA256 when numerical, and (4) a concise statement of what was
removed or changed. Do not answer a protocol criticism only by defending the old text.
