# Prompt to paste into Codex on the compute server

Use the following prompt after uploading/unzipping this repository and both BraTS
datasets:

> You are operating the FD-MRNet JBHI revision experiment package. First read
> AGENTS.md, SERVER_RUNBOOK.md, MANUSCRIPT_REVISION_CHECKLIST.md, and
> RESULTS_INTEGRITY_POLICY.md completely. Do not start formal training yet.
>
> 1. Inspect the server GPUs/CUDA/PyTorch and create the environment.
> 2. Run all unit tests and preflight. Fix only genuine implementation/runtime bugs;
>    do not change the scientific protocol without explaining the consequence.
> 3. Audit BraTS2021 and BraTS2023, apply the supplied BraTS2021 corrections through
>    `--corrections-root`, generate subject-level splits, and run the full voxel-hash
>    cross-dataset overlap audit. Stop and report if counts, shapes, affines, or overlap
>    differ from expectations.
> 4. Materialize only the 2025-seed main configs and run a 10-epoch validation gate.
>    Report loss components, validation patch metrics (explicitly diagnostic), GPU
>    memory, parameter count, geometry EPE/Jacobian/folding, and qualitative output.
>    Do not evaluate the test split.
> 5. If the gate is finite and stable, ask me before launching the complete three-seed
>    main/baseline/ablation matrix. Estimate GPU-hours from the observed pilot speed.
> 6. After approval, use immutable generated configs and separate output directories.
>    Do not copy old paper values and do not generate simulated results.
> 7. When all frozen runs finish, evaluate validation/test exactly once, collect hashes,
>    build Tables I–V/statistics/figures, and run the submission-artifact verifier.
>
> Keep a concise run ledger with command, config SHA256, split hashes, checkpoint hash,
> start/end time, GPU, exit status, and output path. If anything fails, preserve the
> checkpoint/logs and diagnose before resuming.

Before pasting, replace dataset paths in the runbook commands; do not edit paths inside
already materialized formal configs after checkpoints exist.
