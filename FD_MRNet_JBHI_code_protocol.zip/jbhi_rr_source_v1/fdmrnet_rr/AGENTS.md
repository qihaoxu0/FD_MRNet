# Instructions for coding agents

This repository supports a one-major-revision JBHI resubmission. Research integrity and
protocol consistency take priority over matching legacy numbers.

1. Read `SERVER_RUNBOOK.md`, `MANUSCRIPT_REVISION_CHECKLIST.md`, and
   `RESULTS_INTEGRITY_POLICY.md` before running or editing.
2. Never use Set7, cross-modal T2→T1 experiments, three orthogonal inputs, or scales
   other than ×2/×4 in the formal revision.
3. Do not inspect or optimize on test metrics before configuration/checkpoint-selection
   rules are frozen on validation data.
4. Do not remove Gaussian slice-profile blur from the main protocol to raise PSNR. The
   zero-blur setting is an explicitly named sensitivity ablation.
5. Do not copy legacy manuscript values or fabricate missing results. Placeholder files
   are layout-only and must remain visibly marked.
6. Preserve resolved config, split-manifest, checkpoint, and result hashes. A hash
   mismatch is a stop condition, not an invitation to bypass a check.
7. All table values must flow through `collect_results.py` and `build_tables.py
   --submission-mode`.
8. Run `pytest -q`, preflight forward/backward, dataset audit, and a 10-epoch validation
   gate before a full matrix.
9. If code or protocol changes after formal training begins, create a new protocol ID
   and output directory; never overwrite the old run.
10. Report blockers and exact failing commands/logs. Do not silently substitute data,
    methods, checkpoints, or metrics.
