# Separate evaluation protocol for archived weights

This evaluator preserves original configuration, manifest and checkpoint bytes.
It does not upgrade historical summary numbers or engineering candidates to formal
paper evidence. The original `evaluate_full_volume.py` and its checks are unchanged.

Run from this package root so the unrelated top-level `fdmrnet` package does not
shadow imports. Use the environment appropriate to the model; the local PyTorch
2.1.2 environment is used for engineering diagnosis, not silently substituted for
the declared PyTorch 2.6–2.8 formal training runtime.

## Read-only relocation and file identity

Store a new JSON map, for example:

```json
{"mappings": [{"source_prefix": "/original/BraTS2021", "target_prefix": "/mnt/e/data/BraTS2021"}]}
```

The target must be absolute. Prefixes match directory boundaries, longest first;
traversal and duplicate source prefixes are rejected. Original CSV rows are not
rewritten. Freeze the current raw-file SHA256, native XYZ shape and affine:

```bash
python scripts/evaluate_evidence_protocol.py inventory \
  --manifest /archive/original_val.csv --path-map /audit/path_map.json \
  --modality t1 --subject BraTS2021_00502 --out /audit/val00502_inventory.json
```

This inventory establishes identity **at the new freeze time**. It does not prove
that the same files were checked at original training time. A historical image
hash, when available, should be independently compared before freezing.

## Single-case validation engineering protocol

Use actual hashes; the capitalized values below are schema placeholders, not
executable results. References resolve relative to this JSON file; absolute WSL
paths are recommended when running under WSL.

```json
{
  "schema_version": 1,
  "protocol_id": "archived_candidate_val00502_v1",
  "evidence_class": "diagnostic",
  "fixture": false,
  "split": "val",
  "dataset": "BraTS2021",
  "subject_ids": ["BraTS2021_00502"],
  "checkpoint": {"path": "/archive/candidate.pt", "sha256": "RAW_CHECKPOINT_SHA256"},
  "source_config": {"path": "/archive/resolved_config.yaml", "sha256": "CANONICAL_CONFIG_SHA256"},
  "original_manifest": {"path": "/archive/original_val.csv", "sha256": "RAW_MANIFEST_SHA256"},
  "path_map": {"path": "path_map.json", "sha256": "RAW_PATH_MAP_SHA256"},
  "file_inventory": {"path": "val00502_inventory.json", "sha256": "RAW_INVENTORY_SHA256"},
  "freeze": {
    "frozen_at": "ACTUAL_TIME_WITH_TIMEZONE",
    "checkpoint_selection_rule": "engineering_candidate_only",
    "manifest_binding": "bound_at_training",
    "no_test_tuning": true
  }
}
```

`source_config.sha256` is `load_config(path)["_config_sha256"]`, not its raw file
hash. Every other reference SHA is the raw file SHA. The checkpoint's embedded
configuration must independently match the same canonical hash; model weights
load with `strict=True`. A split bound by the checkpoint must match its original
manifest hash. A newly frozen test/external cohort is honestly marked
`not_bound_at_training`, with a real freeze date; metadata is never backdated.

```bash
python scripts/evaluate_evidence_protocol.py evaluate --protocol /audit/protocol.json \
  --out-dir /audit/evaluation --tag candidateB_val00502 --device cuda:0 --threads 4
```

Outputs are `<tag>_subject_metrics.csv`, `<tag>_audit.json` and immutable
`<tag>_source_snapshot/`. The audit hashes the frozen snapshot and separately
records original executed source locations. Existing outputs are never overwritten.
A failed attempt retains its `.lock` reservation; investigate the failure and use
a new tag. Diagnostic patch/overlap/AMP overrides are recorded in the audit.
Full-volume validation remains a diagnostic; it is not a test submission result.

## Method labels and missing segmentation

For main/baseline evaluation the method name must equal the source model factory.
An FD-MRNet checkpoint cannot be called RDN, SuperFormer or DDLSR. An ablation uses
`evaluation_group: "ablations"` and an explicit `method_binding` with
`factory_model`, `variant_name` and
`config_variant_sha256=canonical_hash({"model": cfg["model"], "loss": cfg["loss"]})`.

External CSV rows identify `dataset=BraTS2023` while the audit records the separate
BraTS2021 training dataset. With `split=external` and
`external_eval_without_seg=true`, absent segmentation yields N/A for every tumor
column and an explicit reason. A present but empty tumor mask yields N/A quality
metrics and the genuine zero ROI voxel count. Neither case is filled with zero
quality scores.

## Formal gates and actual training budget

Version 1 accepts only the frozen final-epoch rule, full original subject roster,
non-fixture test/external evaluation and unchanged inference settings. Validation,
500-step candidates, incomplete source epoch budgets and unknown actual budgets
are refused. Nominal `epochs: 300` is never treated as evidence of executed training.

Provide a `training_budget_evidence` raw-file reference. Its independently verified
JSON must bind `checkpoint_sha256`, canonical `source_config_sha256`,
`training_manifest_sha256`, and include positive integer `epochs_completed`,
`optimizer_updates`, `micro_batches`, `effective_global_batch_size`, `world_size`,
`batch_size_per_gpu`, `gradient_accumulation`, `scheduler_steps`, plus
`optimizer: "AdamW"`, `scheduler: {"name": "CosineAnnealingLR", "T_max": EPOCHS}`,
initial `learning_rate`, `weight_decay` and nonempty `source_log_files` mapping
log path to raw SHA256. These counters must come from actual runtime records;
do not manufacture them from a nominal config or infer optimizer updates from
micro-batches. Optimizer updates are checked against the maximum saved parameter
step counter, whose minimum/maximum/unique values are reported. Scheduler state
and batch arithmetic are also checked. A missing or contradictory record blocks
formal status; diagnostic evaluation reports nominal versus observed information.

The evidence schema is, for example (every uppercase token needs a real value
from preserved artifacts; this is not a populated result):

```json
{
  "checkpoint_sha256": "RAW_CHECKPOINT_SHA256",
  "source_config_sha256": "CANONICAL_CONFIG_SHA256",
  "training_manifest_sha256": "RAW_ORIGINAL_TRAIN_MANIFEST_SHA256",
  "epochs_completed": "ACTUAL_POSITIVE_INTEGER",
  "optimizer_updates": "ACTUAL_POSITIVE_INTEGER_MATCHING_SAVED_PARAMETER_STEP_MAX",
  "micro_batches": "ACTUAL_POSITIVE_INTEGER_FROM_RUNTIME_LOG",
  "effective_global_batch_size": "ACTUAL_POSITIVE_INTEGER",
  "world_size": "ACTUAL_POSITIVE_INTEGER",
  "batch_size_per_gpu": "ACTUAL_POSITIVE_INTEGER",
  "gradient_accumulation": "ACTUAL_POSITIVE_INTEGER",
  "scheduler_steps": "ACTUAL_POSITIVE_INTEGER",
  "optimizer": "AdamW",
  "scheduler": {"name": "CosineAnnealingLR", "T_max": "SOURCE_CONFIG_EPOCHS_INTEGER"},
  "learning_rate": "ACTUAL_INITIAL_FLOAT",
  "weight_decay": "ACTUAL_FLOAT",
  "source_log_files": {"/archive/preserved_runtime_log.json": "RAW_LOG_SHA256"}
}
```

Integer/float placeholders above are strings solely to keep the example JSON
parseable: they must be replaced by numbers in a real evidence file. Relative
log paths resolve against the budget evidence JSON's directory. Config binding,
saved initial-LR/base-LR groups, weight decay, scheduler and observed step counts
are checked independently. The evaluator does not manufacture missing runtime
logs or claim that hashing an operator-supplied annotation proves its contents.

## External cohort registration and fresh overlap evidence

This workflow has not run MRI test/external inference or a new full voxel audit.
Formal external evaluation additionally requires `dataset=BraTS2023`,
`subject_ids=null`, a prespecified never-used-for-training/tuning/selection policy,
and truthful `late_binding_reason` if it was not bound in the original checkpoint.

The historical `audit_cross_dataset.py` report has counts and overlap lists, but
does not bind manifest/image hashes. That report alone cannot qualify. Preserve
it as unverified historical binding. A **new actual full voxel audit** must be
frozen with schema version 1 and these fields:

- `status: "completed"`, `full_voxel_hash_performed: true`,
  `independent_external_cohort: true`;
- empty `subject_id_overlap` and `voxel_identical_overlap` lists;
- `dataset_a_manifest_sha256`, `dataset_b_manifest_sha256`,
  `dataset_a_file_inventory_sha256`, `dataset_b_file_inventory_sha256`;
- actual `dataset_a_subjects`, `dataset_b_subjects` and sorted
  `dataset_a_subject_ids`, `dataset_b_subject_ids`.
- `canonical_voxel_hash_algorithm` exactly
  `nibabel.as_closest_canonical; float32; shape+contiguous voxel bytes`.

The protocol supplies raw references `overlap_audit`,
`training_cohort_manifest`, `training_cohort_inventory`,
`training_cohort_path_map`, and `training_split_manifests` with original
`train`, `val`, `test` references. The full BraTS2021 cohort must equal their
non-overlapping union; any checkpoint-bound split SHA must agree. Both cohort
inventories use `--modality both` so T1 and T2 identities are included. The voxel
audit must hash those actual inputs and record the exact canonical voxel algorithm;
the evaluator rechecks their byte identities. These additional metadata fields
cannot be retroactively invented around an old count-only audit.

Independent protocol SHA values differ across checkpoint/config/seed runs. The
collector compares shared evaluation settings, cohort/subject identities and
training budgets separately; it preserves unique run hashes. All manuscript
values must still flow through the verified collector and `build_tables.py
--submission-mode`. No diagnostic output is automatically inserted into a paper.
