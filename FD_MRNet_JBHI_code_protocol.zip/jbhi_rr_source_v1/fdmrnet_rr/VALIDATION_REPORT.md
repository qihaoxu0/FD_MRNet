# Package validation report

Date: 2026-08-26

Completed in the build environment:

- all Python files passed `python -m compileall`;
- every repository YAML configuration loaded and passed protocol validation;
- the full registry materialized 186 unique immutable run configurations;
- all 186 materialized configurations reloaded successfully;
- table aggregation logic was exercised on an in-memory three-seed subject-level sample;
- source search found no Set7 loader/config and no obsolete `fdmrnet_*` metric prefix;
- submission-mode paths and placeholder rejection are implemented.

Not executable in the build environment:

- PyTorch, nibabel, pytest, and CUDA were not installed, so tensor runtime tests,
  forward/backward preflight, NIfTI audits, checkpoint round trips, and GPU profiling
  could not be run here.

These are mandatory server gates, not optional suggestions. Run `pytest -q` and
`scripts/preflight.py` after installing `environment.yml`; do not start formal training
if either fails. No MRI data were accessed and no experimental result was generated in
this build environment.
