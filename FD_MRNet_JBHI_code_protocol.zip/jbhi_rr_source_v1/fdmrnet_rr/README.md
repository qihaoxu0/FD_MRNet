# FD-MRNet JBHI Reject-and-Resubmit Codebase

This repository is a clean-room implementation derived from the method description in
`FD-MRNet(5).pdf` and the reviewer requirements for JBHI-07192-2025. It is designed for
single-input, same-contrast, 3D through-plane MRI super-resolution. T1w and T2w models
are trained independently.

Because the original source code is unavailable, this package is a reviewer-aligned
reimplementation, not a claim that the old manuscript values have been reproduced.
No code can guarantee preservation of those values—especially because the old Table I
and Table II used incompatible, undocumented protocols. The revised code prioritizes a
single defensible protocol and performance-preserving residual learning within it.

## Integrity rules

- Set7 is intentionally excluded.
- Models are trained only on BraTS2021. Main scales remain x2/x4.
- BraTS2023 GLI Training is `excluded_duplicate_of_brats2021`: all 1251 T1/T2 pairs are canonical-voxel-identical to BraTS2021.
- BraTS2023 GLI Validation is a 219-case non-overlapping external evaluation set only; it is not an official test set and is never used for tuning or checkpoint selection.
- Full-volume subject-level metrics are authoritative; patch metrics are diagnostic.
- Tables and figures are generated from immutable CSV/JSON logs.
- Placeholder artifacts are visibly watermarked and rejected by submission-mode tools.
- Do not claim that this clean-room implementation reproduces old manuscript numbers
  until the formal server experiments have completed.
- Never tune against the held-out test set or select a degradation merely because it
  makes a legacy PSNR easier to match.

## Installation

```bash
conda env create -f environment.yml
conda activate fdmrnet-rr
pip install -e .
```

## Expected BraTS layout

```text
DATA_ROOT/
  BraTS2021_00000/
    BraTS2021_00000_t1.nii.gz
    BraTS2021_00000_t2.nii.gz
    BraTS2021_00000_seg.nii.gz
```

BraTS naming variants are discovered by suffix rather than hard-coded subject ranges.

## Workflow

1. Audit and split data:

```bash
python scripts/audit_dataset.py --root /data/BraTS2021 --out manifests/brats2021_audit.json
python scripts/generate_splits.py --root /data/BraTS2021 --out-dir manifests/brats2021 \
  --seed 2025 --train 1001 --val 125 --test 125
```

2. Preflight:

```bash
python scripts/preflight.py --config configs/main/brats2021_t1_x2.yaml
pytest -q
```

3. Train with DDP:

```bash
torchrun --standalone --nproc_per_node=4 scripts/train.py \
  --config configs/main/brats2021_t1_x2.yaml
```

4. Full-volume evaluation:

```bash
python scripts/evaluate_full_volume.py \
  --config configs/main/brats2021_t1_x2.yaml \
  --checkpoint outputs/brats2021_t1_x2/epoch_300.pt \
  --split test
```

5. Materialize three-seed main/baseline/ablation runs and execute the server matrix:

```bash
python scripts/materialize_experiments.py --out-dir generated_configs
```

6. Collect real results, statistics and tables:

```bash
python scripts/collect_results.py --run-manifest generated_configs/run_manifest.csv \
  --out COMPLETED_RESULTS.yaml
python scripts/build_tables.py --registry COMPLETED_RESULTS.yaml --out outputs/tables --submission-mode
python scripts/run_statistics.py --metrics-long outputs/tables/subject_seed_metrics_long.csv \
  --registry COMPLETED_RESULTS.yaml --submission-mode \
  --out outputs/statistics
```

Formal statistics reverify the immutable registry, three seeds, and exact subject
pairing. They keep evaluation splits and explicitly named training regimes separate.
The prespecified one-sided `greater` hypothesis is recorded in each comparison.
Single-patient diagnostics retain the means but report CI/p-values as `N/A`.
Running without `--submission-mode` produces visibly marked `NOT_FOR_SUBMISSION`
diagnostic statistics in a separate output directory.

The conflict-safe table mapping is fixed: Table I = BraTS2021 internal test, Table II =
BraTS2023 GLI Validation external evaluation (whole-brain metrics only), and Table III =
BraTS2021 T1 x4 ablations. All use T1/T2 and x2/x4 as applicable. Tables are never typed manually.

## Server guidance

The paper configuration uses patches in DHW order `[64, 128, 128]`, batch size 4,
300 epochs, AMP, and gradient checkpointing. A 40 GB or larger GPU is recommended.
Reduce per-GPU batch size and use gradient accumulation only when necessary; record the
effective global batch size in every run manifest.

## What this package addresses

- explicit through-plane Gaussian slice-profile degradation;
- exact interpolation naming and parameters;
- subject-level split manifests and leakage checks;
- fixed full-volume metric protocol;
- non-trivial synthetic field supervision for hierarchical offsets;
- field magnitude, Jacobian, folding and endpoint-error evaluation;
- modern baselines and parameter/FLOP-matched controls;
- multi-seed statistics and direct log-to-table generation;
- common-hardware latency and memory measurement;
- resume-safe checkpoints with configuration and split hashes.

## Read before running

- `SERVER_RUNBOOK.md`: exact staged commands for Codex/HPC.
- `MANUSCRIPT_REVISION_CHECKLIST.md`: every paper change and replacement equation.
- `REVIEWER_RESPONSE_EVIDENCE_MATRIX.md`: reviewer concern → code/evidence mapping.
- `EXTERNAL_BASELINES.md`: honest handling of SuperFormer and reviewer-requested DDLSR.
- `RESULTS_INTEGRITY_POLICY.md`: rules preventing placeholder/legacy contamination.

`scripts/make_placeholder_artifacts.py` is optional and produces visibly watermarked
layout aids only. `scripts/verify_artifacts.py` and submission mode reject them.
