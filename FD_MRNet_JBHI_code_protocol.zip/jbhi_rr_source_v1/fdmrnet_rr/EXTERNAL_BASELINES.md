# External baseline policy

## SuperFormer

The authors provide an official repository at
<https://github.com/BCV-Uniandes/SuperFormer>. Its published setup uses HCP data and a
k-space truncation pipeline, so its published numbers are not directly comparable to
the revised BraTS depth-only slice-profile protocol. If used quantitatively:

1. clone the upstream repository separately;
2. record the exact commit and license;
3. keep its network intact;
4. replace only the data adapter so it consumes this repository's immutable manifests
   and LR/HR pairs;
5. train from scratch with the shared seeds and report that this is a protocol
   adaptation, not a reproduction of the HCP table.

The internal `swinir3d` model is a declared compact 3D window-attention control. It must
not be called SuperFormer.

## DDLSR

The reviewer-named paper is “DDLSR: Dual domain learning and Arbitrary-Upsample MRI
Super-Resolution via Spectro-Spatial linear attention,” DOI
<https://doi.org/10.1016/j.bspc.2026.111071>. As of 2026-08-26, no official public code
repository was found in the paper/search records inspected for this revision.

Do not silently reimplement an approximate model and label it DDLSR. The internal
`spectralsr3d` network is only a shared-protocol frequency-domain control. A DDLSR
number may enter the paper only if the authors provide code or sufficient official
implementation detail and the input task is made compatible. Otherwise, cite and
discuss differences in input configuration, arbitrary-scale formulation, frequency
processing, geometry modeling, and evaluation protocol, and state why no direct
quantitative comparison is valid.
