# Executed budget and resume protocol

New independent protocols can set `training.record_actual_budget: true`. This
requires one process/GPU per model job, `num_workers: 0`, complete batch and
accumulation boundaries, and a new empty output directory. Two GPUs can execute
two independent jobs; this is not DDP and does not double a job's global batch.

`training_execution.jsonl` records every completed micro-batch, observed batch
size, loss, attempted optimizer boundary, actual update and native AMP overflow.
Epoch scheduler events are separate from optimizer updates. Each saved
checkpoint carries counters and the execution-log/source/runtime digests.
`*.budget.json` binds those counters to the checkpoint/config/train-manifest
hashes and an immutable `*.execution.jsonl` copy. Runtime package versions and
the training source snapshot are also independently hashed. The collector
recounts the events when `record_actual_budget` is enabled.

AMP overflow reduces the scaler and skips the optimizer update. It is recorded
as an attempt/skip, never as a successful update. Epoch-based cosine scheduling
remains once per completed epoch. Non-finite loss stops the run.

Resume validates configuration, manifests, source, runtime and the exact event
log before rewriting configuration/status. It restores model, Adam moments,
scheduler, scaler and CPU/CUDA RNG. A historical checkpoint without a ledger
cannot resume under this new protocol. An older checkpoint whose log has since
advanced cannot silently roll the current run back; a separately registered
branch would be required.

The current `deterministic: true` utility uses seeded **warn-only** deterministic
algorithms. CUDA 3D grid-sample and average-pooling backward report unsupported
determinism. Exact saved-state restoration is required; a successful restored
update is checked separately from a strict repeated-trajectory comparison.
The strict `1e-6` trajectory threshold is retained and its failed FD-MRNet
outcome must be reported. Do not describe the training trajectory as bitwise
deterministic, or loosen that threshold to conceal a failed check.

Diagnostic preflight/rehearsal budgets are rejected by submission export.
Validation pilots do not establish a converged final training budget or a SOTA
comparison. The compact in-house `SwinIR3D` is not a verified published baseline.
